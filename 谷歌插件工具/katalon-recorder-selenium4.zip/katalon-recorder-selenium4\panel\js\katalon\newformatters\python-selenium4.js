/* ============================================================================
 * Katalon Recorder 7.1.0 集成版 — Python (Selenium 4 + unittest) formatter
 * 把录制命令翻译成 Selenium 4 语法的 Python unittest 脚本。
 * 注册为 newFormatters.pythonSelenium4，导出下拉中显示为
 * "Python (Selenium 4 + unittest)"。
 * ==========================================================================*/
$(document).ready(function () {
  newFormatters.pythonSelenium4 = function (name, commands) {
    var content = formatSelenium4Python(name, commands);
    return {
      content: content,
      extension: 'py',
      mimetype: 'text/x-python'
    };
  };

  // ---- 以下为纯函数：Selenese 命令 -> Selenium 4 Python ----

  function pyStr(s) {
    s = String(s == null ? '' : s);
    function esc(x) {
      return x.replace(/\\/g, '\\\\').replace(/"/g, '\\"')
              .replace(/\r/g, '\\r').replace(/\n/g, '\\n');
    }
    if (/\$\{/.test(s)) {
      var out = '';
      var last = 0;
      var re = /\$\{([a-zA-Z0-9_]+)\}|\{|\}/g;
      var m;
      while ((m = re.exec(s)) !== null) {
        out += s.slice(last, m.index);
        if (m[1] !== undefined) {
          out += '{' + m[1] + '}';
        } else {
          out += m[0] + m[0];
        }
        last = re.lastIndex;
      }
      out += s.slice(last);
      return 'f"' + esc(out) + '"';
    }
    return '"' + esc(s) + '"';
  }

  function pyVarName(nm) {
    var n = String(nm == null ? '' : nm).replace(/[^a-zA-Z0-9_]/g, '_');
    if (!n) n = '_var';
    if (/^[0-9]/.test(n)) n = '_' + n;
    return n;
  }

  function escapeRegex(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function patternToRegexSource(pattern) {
    var p = String(pattern == null ? '' : pattern);
    var m;
    if ((m = /^regexp:(.*)$/.exec(p))) return m[1];
    if ((m = /^regexpi:(.*)$/.exec(p))) return '(?i)' + m[1];
    if ((m = /^regex:(.*)$/.exec(p))) return m[1];
    p = p.replace(/^exact:/, '');
    if (p.indexOf('*') >= 0 || p.indexOf('?') >= 0) {
      p = p.replace(/^glob:/, '');
      var out = '';
      for (var i = 0; i < p.length; i++) {
        var ch = p[i];
        if (ch === '*') out += '.*';
        else if (ch === '?') out += '.';
        else out += escapeRegex(ch);
      }
      return '^' + out + '$';
    }
    return '^' + escapeRegex(p) + '$';
  }

  function textCompare(pattern, expr) {
    var p = String(pattern == null ? '' : pattern);
    var exact = p.replace(/^exact:/, '');
    if (!/^(regexp|regexpi|regex):/.test(p) && exact.indexOf('*') < 0 && exact.indexOf('?') < 0) {
      return { cond: expr + ' == ' + pyStr(exact), msg: expr + ' != ' + pyStr(exact) };
    }
    return {
      cond: 're.search(' + pyStr(patternToRegexSource(p)) + ', ' + expr + ') is not None',
      msg: 'pattern not matched: ' + pyStr(p)
    };
  }

  function parseLocator(target) {
    var t = String(target == null ? '' : target).trim();
    var m = /^(xpath|css|id|name|link|linkText|partialLinkText|tag|tag_name|class|className|dom|ui|identifier)=(.*)$/.exec(t);
    if (m) {
      var type = m[1], val = m[2];
      switch (type) {
        case 'xpath': return { by: 'By.XPATH', value: val };
        case 'css': return { by: 'By.CSS_SELECTOR', value: val };
        case 'id': return { by: 'By.ID', value: val };
        case 'name': return { by: 'By.NAME', value: val };
        case 'link':
        case 'linkText': return { by: 'By.LINK_TEXT', value: val.replace(/^exact:/, '') };
        case 'partialLinkText': return { by: 'By.PARTIAL_LINK_TEXT', value: val };
        case 'tag':
        case 'tag_name': return { by: 'By.TAG_NAME', value: val };
        case 'class':
        case 'className': return { by: 'By.CLASS_NAME', value: val };
        default: return { error: 'Unsupported locator strategy: ' + type };
      }
    }
    if (t.indexOf('//') === 0 || t.indexOf('(') === 0) {
      return { by: 'By.XPATH', value: t };
    }
    if (t.indexOf('document.') === 0 || /^javascript\{/.test(t) || /^ui=/.test(t)) {
      return { error: 'Unsupported locator: ' + t };
    }
    return { by: 'By.ID', value: t };
  }

  function findExpr(target) {
    var l = parseLocator(target);
    if (l.error) return { error: l.error };
    return { expr: 'driver.find_element(' + l.by + ', ' + pyStr(l.value) + ')' };
  }

  function parseSelect(value) {
    var v = String(value == null ? '' : value).trim();
    var m = /^(index|value|label|id)=(.*)$/.exec(v);
    if (m) {
      var type = m[1], val = m[2];
      if (type === 'index') return { method: 'select_by_index', arg: 'int(' + pyStr(val) + ')' };
      if (type === 'value') return { method: 'select_by_value', arg: pyStr(val) };
      return { method: 'select_by_visible_text', arg: pyStr(val) };
    }
    return { method: 'select_by_visible_text', arg: pyStr(v) };
  }

  var IND = '        ';

  function genAssert(cmd, condition, msg) {
    if (/^verify/.test(cmd)) {
      return IND + 'if not (' + condition + '):\n' + IND + '    self.verificationErrors.append(' + pyStr(msg) + ')';
    }
    return IND + 'self.assertTrue(' + condition + ', ' + pyStr(msg) + ')';
  }

  function textPresentCond(text) {
    var p = String(text == null ? '' : text).replace(/^exact:/, '');
    if (p.indexOf('*') >= 0 || p.indexOf('?') >= 0) {
      return 're.search(' + pyStr(patternToRegexSource(p)) + ', driver.page_source) is not None';
    }
    return pyStr(p) + ' in driver.page_source';
  }

  function genCommand(cmd) {
    var c = cmd.command, t = cmd.target, v = cmd.value;
    var f, l, sel, pm;
    switch (c) {
      case 'open': {
        var url = String(t == null ? '' : t).trim();
        if (/^(\w+:)?\/\//.test(url) || /^about:/.test(url)) {
          return IND + 'driver.get(' + pyStr(url) + ')';
        }
        return IND + 'driver.get(self.base_url + ' + pyStr(url) + ')';
      }
      case 'click':
      case 'clickAndWait':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return IND + f.expr + '.click()';
      case 'doubleClick':
      case 'doubleClickAndWait':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return IND + 'ActionChains(driver).double_click(' + f.expr + ').perform()';
      case 'type':
      case 'typeAndWait':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return IND + '_el = ' + f.expr + '\n' + IND + '_el.clear()\n' + IND + '_el.send_keys(' + pyStr(v) + ')';
      case 'sendKeys':
      case 'sendKeysAndWait':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return IND + f.expr + '.send_keys(' + pyStr(v) + ')';
      case 'check':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return IND + 'if not ' + f.expr + '.is_selected():\n' + IND + '    ' + f.expr + '.click()';
      case 'uncheck':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return IND + 'if ' + f.expr + '.is_selected():\n' + IND + '    ' + f.expr + '.click()';
      case 'select':
      case 'selectAndWait':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        sel = parseSelect(v);
        return IND + 'Select(' + f.expr + ').' + sel.method + '(' + sel.arg + ')';
      case 'pause': {
        var ms = parseInt(v, 10);
        if (isNaN(ms)) ms = 1000;
        return IND + 'time.sleep(' + (ms / 1000.0) + ')';
      }
      case 'refresh':
        return IND + 'driver.refresh()';
      case 'goBack':
        return IND + 'driver.back()';
      case 'close':
        return IND + 'driver.close()';
      case 'submit':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return IND + f.expr + '.submit()';
      case 'echo':
        return IND + 'print(' + pyStr(t) + ')';
      case 'store':
        return IND + pyVarName(v) + ' = ' + pyStr(t);
      case 'storeText':
      case 'storeValue':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return IND + pyVarName(v) + ' = ' + f.expr +
               (c === 'storeValue' ? '.get_attribute("value")' : '.text');
      case 'storeTitle':
        return IND + pyVarName(v) + ' = driver.title';
      case 'storeAttribute': {
        var at = String(t).split('@');
        f = findExpr(at[0]);
        if (f.error) return IND + '# ' + f.error;
        return IND + pyVarName(v) + ' = ' + f.expr + '.get_attribute(' + pyStr(at[1]) + ')';
      }
      case 'assertText':
      case 'verifyText':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        pm = textCompare(v, f.expr + '.text');
        return genAssert(c, pm.cond, pm.msg);
      case 'assertValue':
      case 'verifyValue':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        pm = textCompare(v, f.expr + '.get_attribute("value")');
        return genAssert(c, pm.cond, pm.msg);
      case 'assertTitle':
      case 'verifyTitle':
        pm = textCompare(v, 'driver.title');
        return genAssert(c, pm.cond, pm.msg);
      case 'assertTextPresent':
      case 'verifyTextPresent':
        return genAssert(c, textPresentCond(t), 'text not present: ' + t);
      case 'assertTextNotPresent':
      case 'verifyTextNotPresent':
        return genAssert(c, 'not (' + textPresentCond(t) + ')', 'text unexpectedly present: ' + t);
      case 'assertElementPresent':
      case 'verifyElementPresent':
        l = parseLocator(t);
        if (l.error) return IND + '# ' + l.error;
        return genAssert(c, 'self.is_element_present(' + l.by + ', ' + pyStr(l.value) + ')', 'element not present: ' + t);
      case 'assertElementNotPresent':
      case 'verifyElementNotPresent':
        l = parseLocator(t);
        if (l.error) return IND + '# ' + l.error;
        return genAssert(c, 'not self.is_element_present(' + l.by + ', ' + pyStr(l.value) + ')', 'element unexpectedly present: ' + t);
      case 'assertVisible':
      case 'verifyVisible':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return genAssert(c, f.expr + '.is_displayed()', 'element not visible: ' + t);
      case 'assertNotVisible':
      case 'verifyNotVisible':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return genAssert(c, 'not ' + f.expr + '.is_displayed()', 'element unexpectedly visible: ' + t);
      case 'assertChecked':
      case 'verifyChecked':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return genAssert(c, f.expr + '.is_selected()', 'element not checked: ' + t);
      case 'assertNotChecked':
      case 'verifyNotChecked':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        return genAssert(c, 'not ' + f.expr + '.is_selected()', 'element unexpectedly checked: ' + t);
      case 'assertSelectedLabel':
      case 'verifySelectedLabel':
        f = findExpr(t);
        if (f.error) return IND + '# ' + f.error;
        pm = textCompare(v, 'Select(' + f.expr + ').first_selected_option.text');
        return genAssert(c, pm.cond, pm.msg);
      case 'assertAlert':
      case 'verifyAlert':
      case 'assertConfirmation':
      case 'verifyConfirmation':
        pm = textCompare(t, 'driver.switch_to.alert.text');
        return genAssert(c, pm.cond, pm.msg);
      case 'waitForElementPresent':
      case 'waitForElementVisible':
      case 'waitForVisible':
        l = parseLocator(t);
        if (l.error) return IND + '# ' + l.error;
        var wc = (c === 'waitForElementPresent') ? 'presence_of_element_located' : 'visibility_of_element_located';
        return IND + 'WebDriverWait(driver, 10).until(EC.' + wc + '((' + l.by + ', ' + pyStr(l.value) + ')))';
      case 'waitForElementNotPresent':
      case 'waitForNotVisible':
        l = parseLocator(t);
        if (l.error) return IND + '# ' + l.error;
        var wc2 = (c === 'waitForElementNotPresent') ? 'presence_of_element_located' : 'visibility_of_element_located';
        return IND + 'WebDriverWait(driver, 10).until_not(EC.' + wc2 + '((' + l.by + ', ' + pyStr(l.value) + ')))';
      case 'waitForText': {
        l = parseLocator(t);
        if (l.error) return IND + '# ' + l.error;
        return IND + 'WebDriverWait(driver, 10).until(EC.text_to_be_present_in_element((' + l.by + ', ' + pyStr(l.value) + '), ' + pyStr(v) + '))';
      }
      case 'waitForValue':
        l = parseLocator(t);
        if (l.error) return IND + '# ' + l.error;
        return IND + 'WebDriverWait(driver, 10).until(lambda _d: _d.find_element(' + l.by + ', ' + pyStr(l.value) + ').get_attribute("value") == ' + pyStr(v) + ')';
      case 'waitForTitle':
        return IND + 'WebDriverWait(driver, 10).until(EC.title_is(' + pyStr(v) + '))';
      case 'waitForAlertPresent':
        return IND + 'WebDriverWait(driver, 10).until(EC.alert_is_present())';
      case 'waitForTextPresent':
        return IND + 'WebDriverWait(driver, 10).until(lambda _d: ' + textPresentCond(t) + ')';
      default:
        return IND + '# WARNING: unsupported command "' + c + '" (target=' + String(t) + ', value=' + String(v) + ')';
    }
  }

  function formatSelenium4Python(name, commands) {
    // 与 Katalon Recorder 的 testClassName 命名保持一致（CamelCase）
    var _capitalize = function (s) {
      return s.charAt(0).toUpperCase() + s.substring(1).toLowerCase();
    };
    var safeName = String(name == null ? '' : name).split(/[^0-9A-Za-z]+/).map(_capitalize).join('');
    if (!safeName) safeName = 'GeneratedTest';
    if (/^[0-9]/.test(safeName)) safeName = '_' + safeName;
    var header =
      '# -*- coding: utf-8 -*-\n' +
      '# Generated by Katalon Recorder (integrated "Python (Selenium 4 + unittest)" formatter)\n' +
      'from selenium import webdriver\n' +
      'from selenium.webdriver.common.by import By\n' +
      'from selenium.webdriver.support.ui import WebDriverWait\n' +
      'from selenium.webdriver.support import expected_conditions as EC\n' +
      'from selenium.webdriver.support.ui import Select\n' +
      'from selenium.webdriver.common.action_chains import ActionChains\n' +
      'from selenium.common.exceptions import NoSuchElementException\n' +
      'import unittest, time, re\n\n\n' +
      'class ' + safeName + '(unittest.TestCase):\n\n' +
      '    def setUp(self):\n' +
      '        # 如需使用 Firefox，请改为 self.driver = webdriver.Firefox()\n' +
      '        self.driver = webdriver.Chrome()\n' +
      '        self.driver.implicitly_wait(30)\n' +
      '        self.base_url = "https://www.google.com/"\n' +
      '        self.verificationErrors = []\n\n' +
      '    def test_1(self):\n' +
      '        driver = self.driver\n';

    var body = '';
    var cmds = commands || [];
    for (var i = 0; i < cmds.length; i++) {
      var c = cmds[i];
      if (c && c.command) {
        body += genCommand(c) + '\n';
      }
    }

    var footer =
      '\n' +
      '    def is_element_present(self, how, what):\n' +
      '        try:\n' +
      '            self.driver.find_element(by=how, value=what)\n' +
      '        except NoSuchElementException:\n' +
      '            return False\n' +
      '        return True\n\n' +
      '    def tearDown(self):\n' +
      '        self.driver.quit()\n' +
      '        self.assertEqual([], self.verificationErrors)\n\n\n' +
      'if __name__ == "__main__":\n' +
      '    unittest.main()\n';

    return header + body + footer;
  }
});
