const renderKSScript = async (outputScript) => {
  const $textarea = $("#export-to-KS-script");
  const textarea = $textarea.get(0);

  // 根据所选框架选择高亮模式（Python 相关用 Python 模式，其余用 Groovy）
  const language = $("#export-to-KS-select-script-language").val();
  let mode = 'text/x-groovy';
  if (typeof language === 'string' && language.indexOf('python') >= 0) {
    mode = 'text/x-python';
  }

  const codeMirrorOptions = {
    lineNumbers: true,
    matchBrackets: true,
    readOnly: true,
    lineWrapping: true,
    mode: mode
  };
  let codeMirror = $textarea.data('cm');
  if (codeMirror) {
    codeMirror.toTextArea();
  }
  $textarea.data('cm', null);
  textarea.value = outputScript;
  codeMirror = CodeMirror.fromTextArea(textarea, codeMirrorOptions);
  $('.CodeMirror').removeClass('kat-90').addClass('kat-75');
  $textarea.data('cm', codeMirror);
}

export { renderKSScript }