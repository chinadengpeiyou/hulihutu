# Katalon Recorder 7.1.0 集成版 — 内置 "Python (Selenium 4 + unittest)" 导出格式

这是**完整的 Katalon Recorder 7.1.0**（MV3），已在内部集成了 Selenium 4 Python 导出格式。
不再依赖任何外部插件——格式直接写在 KR 里面，导出下拉中会多出一项：

> **Python (Selenium 4 + unittest)**

用它导出的脚本使用 Selenium 4 新语法（`By` / `find_element(By.XPATH, ...)` / `WebDriverWait` / `Select`），
可在 Python 3 + Selenium 4（当前最新版）下直接运行。

## 安装步骤

1. **解压**本文件夹到**固定位置**，例如 `C:\Users\Administrator\Downloads\katalon-recorder-selenium4`
   （**装好后不要移动、不要删除**，否则扩展会失效）。

2. 便携 Chrome 打开 `chrome://extensions`，开启右上角**开发者模式**。

3. **先移除旧版 Katalon Recorder**：在扩展列表找到 **"Katalon Recorder (Selenium tests generator)"** 点 **移除**。
   （不移除会同时存在两个 KR，录制互相干扰。）

4. 点 **加载未打包的扩展程序**，选择第 1 步解压的 `katalon-recorder-selenium4` 文件夹。

5. 确认扩展卡片显示 **Katalon Recorder 7.1.0** 且已启用。

## 使用方法

1. 录制测试用例（和以前一样）；
2. 点 **Export**；
3. 在 **Format / Select a framework** 下拉中选择 **"Python (Selenium 4 + unittest)"**；
4. 导出得到的 `.py` 即为 Selenium 4 语法的 unittest 脚本。

## 运行

```bash
pip install selenium
python 你的脚本.py
```

默认 Chrome；要 Firefox 就把 `setUp` 里 `webdriver.Chrome()` 改成 `webdriver.Firefox()`。

## 重要：之前录制的数据

新加载的集成版 KR 是一个**新的扩展实例（ID 不同）**，旧 KR 里已录制的测试用例**不会自动带过来**。
迁移方法：

1. **在旧 KR 里先备份**（卸载前）：选中测试套件 → 用 KR 的 **Export Test Suite / Export Test Case** 导出为 `.html` 文件；
2. 加载集成版 KR 后，用它菜单里的 **Import** 导入刚才的 `.html`；
3. 或者干脆重新录制（KR 录制很简单）。

## 已支持命令（集成 formatter）

`open / click / doubleClick / type / sendKeys / check / uncheck / select / pause / refresh / goBack / close / submit / echo / store* / assert*/verify*（Text/Value/Title/ElementPresent/Visible/Checked/SelectedLabel/Alert 等）/ waitFor*`，
定位支持 xpath/css/id/name/link/partialLinkText/tag/class；不支持的命令会输出 `# WARNING:` 注释，脚本仍可运行。
