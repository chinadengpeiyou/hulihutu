import { Menu } from "../../models/menu/menu.js";
import { MenuItem } from "../../models/menu/menu-item.js";
import {
    generateAddCommand,
    generateCopyCommand,
    generateDeleteAllCommand,
    generateDeleteSelectedCommand,
    generatePasteCommand,
    generateSetBreakpointCommand,
} from "../../services/records-grid-service/command-generators.js";


const addItem = new MenuItem("grid-add", `添加测试步骤 <span class="hotKey">Ctrl+I</span>`, generateAddCommand);
const deleteItem = new MenuItem("grid-delete", `删除命令 <span class="hotKey"></span>`, generateDeleteSelectedCommand)
const deleteAllItem = new MenuItem("grid-deleteAll", `删除所有命令`, generateDeleteAllCommand);
const copyItem = new MenuItem("grid-copy", `复制命令 <span class="hotKey">Ctrl+C</span>`, generateCopyCommand);
const pasteItem = new MenuItem("grid-paste", `粘贴命令 <span class="hotKey">Ctrl+V</span>`, generatePasteCommand);
const breakpointItem = new MenuItem("grid-breakpoint", `切换断点 </a><span class="hotKey">Ctrl+B</span>`, generateSetBreakpointCommand);

const commandGridMenu = new Menu("command-grid-menu");
commandGridMenu.add(addItem);
commandGridMenu.add(breakpointItem);
// commandGridMenu.add(deleteItem);
// commandGridMenu.add(deleteAllItem);
// commandGridMenu.add(copyItem);
// commandGridMenu.add(pasteItem);


export { commandGridMenu };