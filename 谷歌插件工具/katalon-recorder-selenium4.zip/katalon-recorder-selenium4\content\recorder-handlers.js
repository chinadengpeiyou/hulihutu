/*
 * Copyright 2017 SideeX committers
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// capture interactions

function getEventTarget(event) {
    if (!event) {
        return event;
    }
    return event._target || event.target;
}


var typeTarget;
var typeLock = 0;
Recorder.prototype.checkForm = function (targetName, target) {
    let atrList = ['id', 'name', 'class'];
    let tempTarget = target;
    if (targetName === 'form'
        && atrList.some(atr => target.hasAttribute(atr))
        && !target.hasAttribute("onsubmit")
        && !target.hasAttribute("ng-submit")
    ) {
        if (tempTarget.hasAttribute("id"))
            this.record("submit", [["id=" + tempTarget.id, "id"]], "");
        else if (tempTarget.hasAttribute("name"))
            this.record("submit", [["name=" + tempTarget.name, "name"]], "");
        else {
            this.record("submit", [["css=." + tempTarget.classList[0]]], "");
        }
    } else
        this.record("sendKeys", this.locatorBuilders.buildAll(enterTarget), "${KEY_ENTER}");
}

Recorder.inputTypes = ["text", "password", "file", "datetime", "datetime-local", "date", "month", "time", "week", "number", "range", "email", "url", "search", "tel", "color"];
Recorder.addEventHandler('type', 'change', function (event) {
    // © Chen-Chieh Ping, SideeX Team
    const eventTarget = getEventTarget(event);
    if (eventTarget.tagName && !preventType && typeLock == 0 && (typeLock = 1)) {
        // END
        var tagName = eventTarget.tagName.toLowerCase();
        var type = eventTarget.type;
        if ('input' == tagName && Recorder.inputTypes.indexOf(type) >= 0) {
            if (eventTarget.value.length > 0) {
                this.record("type", this.locatorBuilders.buildAll(eventTarget), eventTarget.value);

                // © Chen-Chieh Ping, SideeX Team
                if (enterTarget != null) {
                    var tempTarget = eventTarget.parentElement;
                    var formChk = tempTarget.tagName.toLowerCase();
                    while (formChk != 'form' && formChk != 'body') {
                        tempTarget = tempTarget.parentElement;
                        formChk = tempTarget.tagName.toLowerCase();
                    }
                    this.checkForm(formChk, tempTarget);
                    enterTarget = null;
                }
                // END
            } else {
                this.record("type", this.locatorBuilders.buildAll(eventTarget), eventTarget.value);
            }
        } else if ('textarea' == tagName) {
            this.record("type", this.locatorBuilders.buildAll(eventTarget), eventTarget.value);
        }
    }
    typeLock = 0;
});

Recorder.addEventHandler('type', 'input', function (event) {
    const eventTarget = getEventTarget(event);
    typeTarget = eventTarget;
});

// © Jie-Lin You, SideeX Team
var preventClickTwice = false;
Recorder.addEventHandler('clickAt', 'click', function (event) {
    const eventTarget = getEventTarget(event);
    if (event.button == 0 && !preventClick && event.isTrusted) {
        if (!preventClickTwice) {
            var top = event.pageY,
                left = event.pageX;
            var element = eventTarget;
            do {
                top -= element.offsetTop;
                left -= element.offsetLeft;
                element = element.offsetParent;
            } while (element);
            var target = eventTarget;
            if (eventTarget.parentNode.id !== "popupInjectionKR") {
                this.record("click", this.locatorBuilders.buildAll(eventTarget), '');
                var arrayTest = this.locatorBuilders.buildAll(eventTarget);
                preventClickTwice = true;
            }

        }
        setTimeout(function () { preventClickTwice = false; }, 30);
    }
}, true);
// END

// © Chen-Chieh Ping, SideeX Team
Recorder.addEventHandler('doubleClickAt', 'dblclick', function (event) {
    var top = event.pageY,
        left = event.pageX;
    var element = getEventTarget(event);
    do {
        top -= element.offsetTop;
        left -= element.offsetLeft;
        element = element.offsetParent;
    } while (element);
    if (element.parentNode.id !== "popupInjectionKR") {
        this.record("doubleClick", this.locatorBuilders.buildAll(element), '');
    }
}, true);
// END

// © Chen-Chieh Ping, SideeX Team
var focusTarget = null;
var focusValue = null;
var tempValue = null;
var preventType = false;
var inp = document.getElementsByTagName("input");
for (var i = 0; i < inp.length; i++) {
    if (Recorder.inputTypes.indexOf(inp[i].type) >= 0) {
        inp[i].addEventListener("focus", function (event) {
            const eventTarget = getEventTarget(event);
            focusTarget = eventTarget;
            focusValue = focusTarget.value;
            tempValue = focusValue;
            preventType = false;
        });
        inp[i].addEventListener("blur", function (event) {
            focusTarget = null;
            focusValue = null;
            tempValue = null;
        });
    }
}
// END

// © Chen-Chieh Ping, SideeX Team
var preventClick = false;
var enterTarget = null;
var enterValue = null;
var tabCheck = null;
Recorder.addEventHandler('sendKeys', 'keydown', function (event) {
    const eventTarget = getEventTarget(event);
    if (eventTarget.tagName) {
        var key = event.keyCode;
        var tagName = eventTarget.tagName.toLowerCase();
        var type = eventTarget.type;
        if (tagName == 'input' && Recorder.inputTypes.indexOf(type) >= 0) {
            if (key == 13) {
                enterTarget = eventTarget;
                enterValue = enterTarget.value;
                var tempTarget = eventTarget.parentElement;
                var formChk = tempTarget.tagName.toLowerCase();
                //console.log(tempValue + " " + enterTarget.value + " " + tabCheck + " " + enterTarget + " " + focusValue);
                // console.log(focusValue);
                // console.log(enterTarget.value);
                if (tempValue == enterTarget.value && tabCheck == enterTarget) {
                    this.record("sendKeys", this.locatorBuilders.buildAll(enterTarget), "${KEY_ENTER}");
                    enterTarget = null;
                    preventType = true;
                } else if (focusValue == enterTarget.value) {
                    while (formChk != 'form' && formChk != 'body') {
                        tempTarget = tempTarget.parentElement;
                        formChk = tempTarget.tagName.toLowerCase();
                    }
                    this.checkForm(formChk, tempTarget);
                    enterTarget = null;
                }
                if (typeTarget.tagName && !preventType && (typeLock = 1)) {
                    // END
                    var tagName = typeTarget.tagName.toLowerCase();
                    var type = typeTarget.type;
                    if ('input' == tagName && Recorder.inputTypes.indexOf(type) >= 0) {
                        if (typeTarget.value.length > 0) {
                            this.record("type", this.locatorBuilders.buildAll(typeTarget), typeTarget.value);

                            // © Chen-Chieh Ping, SideeX Team
                            if (enterTarget != null) {
                                var tempTarget = typeTarget.parentElement;
                                var formChk = tempTarget.tagName.toLowerCase();
                                while (formChk != 'form' && formChk != 'body') {
                                    tempTarget = tempTarget.parentElement;
                                    formChk = tempTarget.tagName.toLowerCase();
                                }
                                this.checkForm(formChk, tempTarget);
                                enterTarget = null;
                            }
                            // END
                        } else {
                            this.record("type", this.locatorBuilders.buildAll(typeTarget), typeTarget.value);
                        }
                    } else if ('textarea' == tagName) {
                        this.record("type", this.locatorBuilders.buildAll(typeTarget), typeTarget.value);
                    }
                }
                preventClick = true;
                setTimeout(function () {
                    preventClick = false;
                }, 500);
                setTimeout(function () {
                    if (enterValue != eventTarget.value) enterTarget = null;
                }, 50);
            }

            var tempbool = false;
            if ((key == 38 || key == 40) && eventTarget.value != '') {
                if (focusTarget != null && focusTarget.value != tempValue) {
                    tempbool = true;
                    tempValue = focusTarget.value;
                }
                if (tempbool) {
                    this.record("type", this.locatorBuilders.buildAll(eventTarget), tempValue);
                }

                setTimeout(function () {
                    tempValue = focusTarget.value;
                }, 250);

                if (key == 38) this.record("sendKeys", this.locatorBuilders.buildAll(eventTarget), "${KEY_UP}");
                else this.record("sendKeys", this.locatorBuilders.buildAll(eventTarget), "${KEY_DOWN}");
                tabCheck = eventTarget;
            }
            if (key == 9) {
                if (tabCheck == eventTarget) {
                    this.record("sendKeys", this.locatorBuilders.buildAll(eventTarget), "${KEY_TAB}");
                    preventType = true;
                }
            }
        }
    }
}, true);
// END

// © Shuo-Heng Shih, SideeX Team
Recorder.addEventHandler('dragAndDrop', 'mousedown', function (event) {
    var self = this;
    if (event.clientX < window.document.documentElement.clientWidth && event.clientY < window.document.documentElement.clientHeight) {
        this.mousedown = event;
        this.mouseup = setTimeout(function () {
            delete self.mousedown;
        }.bind(this), 200);

        this.selectMouseup = setTimeout(function () {
            self.selectMousedown = event;
        }.bind(this), 200);
    }
    this.mouseoverQ = [];
    
    const eventTarget = getEventTarget(event);
    if (eventTarget.nodeName) {
        var tagName = eventTarget.nodeName.toLowerCase();
        if ('option' == tagName) {
            var parent = eventTarget.parentNode;
            if (parent.multiple) {
                var options = parent.options;
                for (var i = 0; i < options.length; i++) {
                    options[i]._wasSelected = options[i].selected;
                }
            }
        }
    }
}, true);
// END

// © Shuo-Heng Shih, SideeX Team
Recorder.addEventHandler('dragAndDrop', 'mouseup', function (event) {
    clearTimeout(this.selectMouseup);
    const eventTarget = getEventTarget(event);
    if (this.selectMousedown) {
        var x = event.clientX - this.selectMousedown.clientX;
        var y = event.clientY - this.selectMousedown.clientY;

        function getSelectionText() {
            var text = "";
            var activeEl = window.document.activeElement;
            var activeElTagName = activeEl ? activeEl.tagName.toLowerCase() : null;
            if (activeElTagName == "textarea" || activeElTagName == "input") {
                text = activeEl.value.slice(activeEl.selectionStart, activeEl.selectionEnd);
            } else if (window.getSelection) {
                text = window.getSelection().toString();
            }
            return text.trim();
        }

        if (this.selectMousedown && event.button === 0 && (x + y) && (event.clientX < window.document.documentElement.clientWidth && event.clientY < window.document.documentElement.clientHeight) && getSelectionText() === '') {
            var sourceRelateX = this.selectMousedown.pageX - getEventTarget(this.selectMousedown).getBoundingClientRect().left - window.scrollX;
            var sourceRelateY = this.selectMousedown.pageY - getEventTarget(this.selectMousedown).getBoundingClientRect().top - window.scrollY;
            var targetRelateX, targetRelateY;
            if (!!this.mouseoverQ.length && this.mouseoverQ[1].relatedTarget == getEventTarget(this.mouseoverQ[0]) && getEventTarget(this.mouseoverQ[0]) == eventTarget) {
                targetRelateX = event.pageX - getEventTarget(this.mouseoverQ[1]).getBoundingClientRect().left - window.scrollX;
                targetRelateY = event.pageY - getEventTarget(this.mouseoverQ[1]).getBoundingClientRect().top - window.scrollY;
                // this.record("mouseDownAt", this.locatorBuilders.buildAll(getEventTarget(this.selectMousedown)), sourceRelateX + ',' + sourceRelateY);
                // this.record("mouseMoveAt", this.locatorBuilders.buildAll(getEventTarget(this.mouseoverQ[1])), targetRelateX + ',' + targetRelateY);
                // this.record("mouseUpAt", this.locatorBuilders.buildAll(getEventTarget(this.mouseoverQ[1])), targetRelateX + ',' + targetRelateY);
            } else {
                targetRelateX = event.pageX - eventTarget.getBoundingClientRect().left - window.scrollX;
                targetRelateY = event.pageY - eventTarget.getBoundingClientRect().top - window.scrollY;
                // this.record("mouseDownAt", this.locatorBuilders.buildAll(eventTarget), targetRelateX + ',' + targetRelateY);
                // this.record("mouseMoveAt", this.locatorBuilders.buildAll(eventTarget), targetRelateX + ',' + targetRelateY);
                // this.record("mouseUpAt", this.locatorBuilders.buildAll(eventTarget), targetRelateX + ',' + targetRelateY);
            }
        }
    } else {
        if (this.mousedown) {
            delete this.clickLocator;
            delete this.mouseup;
            var x = event.clientX - this.mousedown.clientX;
            var y = event.clientY - this.mousedown.clientY;
            const mouseDownTarget = getEventTarget(this.mousedown);

            if (this.mousedown && mouseDownTarget !== eventTarget && !(x + y)) {
                // this.record("mouseDown", this.locatorBuilders.buildAll(mouseDownTarget), '');
                // this.record("mouseUp", this.locatorBuilders.buildAll(eventTarget), '');
            } else if (this.mousedown && mouseDownTarget === eventTarget) {
                var self = this;
                var target = this.locatorBuilders.buildAll(mouseDownTarget);
                // setTimeout(function() {
                //     if (!self.clickLocator)
                //         this.record("click", target, '');
                // }.bind(this), 100);
            }
        }
    }
    delete this.mousedown;
    delete this.selectMousedown;
    delete this.mouseoverQ;

}, true);
// END

// © Shuo-Heng Shih, SideeX Team
Recorder.addEventHandler('dragAndDropToObject', 'dragstart', function (event) {
    var self = this;
    this.dropLocator = setTimeout(function () {
        self.dragstartLocator = event;
    }.bind(this), 200);
}, true);
// END

// © Shuo-Heng Shih, SideeX Team
Recorder.addEventHandler('dragAndDropToObject', 'drop', function (event) {
    clearTimeout(this.dropLocator);
    const eventTarget = getEventTarget(event);
    if (this.dragstartLocator && event.button == 0 && getEventTarget(this.dragstartLocator) !== eventTarget) {
        //value no option
        this.record("dragAndDropToObject", this.locatorBuilders.buildAll(getEventTarget(this.dragstartLocator)), this.locatorBuilders.build(eventTarget));
    }
    delete this.dragstartLocator;
    delete this.selectMousedown;
}, true);
// END

// © Shuo-Heng Shih, SideeX Team
var prevTimeOut = null;
Recorder.addEventHandler('runScript', 'scroll', function (event) {
    const eventTarget = getEventTarget(event);
    if (pageLoaded === true) {
        var self = this;
        this.scrollDetector = eventTarget;
        clearTimeout(prevTimeOut);
        prevTimeOut = setTimeout(function () {
            delete self.scrollDetector;
        }.bind(self), 500);
    }
}, true);
// END

// © Shuo-Heng Shih, SideeX Team
var nowNode = 0;
Recorder.addEventHandler('mouseOver', 'mouseover', function (event) {
    if (window.document.documentElement)
        nowNode = window.document.documentElement.getElementsByTagName('*').length;
    var self = this;
    const eventTarget = getEventTarget(event);
    if (pageLoaded === true) {
        var clickable = this.findClickableElement(eventTarget);
        if (clickable) {
            this.nodeInsertedLocator = eventTarget;
            setTimeout(function () {
                delete self.nodeInsertedLocator;
            }.bind(self), 500);

            this.nodeAttrChange = this.locatorBuilders.buildAll(eventTarget);
            this.nodeAttrChangeTimeout = setTimeout(function () {
                delete self.nodeAttrChange;
            }.bind(self), 10);
        }
        //drop target overlapping
        if (this.mouseoverQ) //mouse keep down
        {
            if (this.mouseoverQ.length >= 3)
                this.mouseoverQ.shift();
            this.mouseoverQ.push(event);
        }
    }
}, true);
// END

// © Shuo-Heng Shih, SideeX Team
Recorder.addEventHandler('mouseOut', 'mouseout', function (event) {
    const eventTarget = getEventTarget(event);
    if (this.mouseoutLocator !== null && eventTarget === this.mouseoutLocator) {
        // this.record("mouseOut", this.locatorBuilders.buildAll(eventTarget), '');
    }
    delete this.mouseoutLocator;
}, true);
// END

// © Shuo-Heng Shih, SideeX Team
Recorder.addEventHandler('mouseOver', 'DOMNodeInserted', function (event) {
    if (pageLoaded === true && window.document.documentElement.getElementsByTagName('*').length > nowNode) {
        var self = this;
        if (this.scrollDetector) {
            //TODO: fix target
            // this.record("runScript", [
            //     [
            //         ["window.scrollTo(0," + window.scrollY + ")", ]
            //     ]
            // ], '');
            pageLoaded = false;
            setTimeout(function () {
                pageLoaded = true;
            }.bind(self), 550);
            delete this.scrollDetector;
            delete this.nodeInsertedLocator;
        }
        if (this.nodeInsertedLocator) {
            // this.record("mouseOver", this.locatorBuilders.buildAll(this.nodeInsertedLocator), '');
            this.mouseoutLocator = this.nodeInsertedLocator;
            delete this.nodeInsertedLocator;
            delete this.mouseoverLocator;
        }
    }
}, true);
// END

// © Shuo-Heng Shih, SideeX Team
var readyTimeOut = null;
var pageLoaded = true;
Recorder.addEventHandler('checkPageLoaded', 'readystatechange', function (event) {
    var self = this;
    if (window.document.readyState === 'loading') {
        pageLoaded = false;
    } else {
        pageLoaded = false;
        clearTimeout(readyTimeOut);
        readyTimeOut = setTimeout(function () {
            pageLoaded = true;
        }.bind(self), 1500); //setReady after complete 1.5s
    }
}, true);
// END

// © Ming-Hung Hsu, SideeX Team
Recorder.addEventHandler('contextMenu', 'contextmenu', async function (event) {
    var myPort = await browser.runtime.connect();
    const eventTarget = getEventTarget(event);
    var tmpText = this.locatorBuilders.buildAll(eventTarget);
    var tmpVal = getText(eventTarget);
    var tmpTitle = normalizeSpaces(eventTarget.ownerDocument.title);
    var self = this;
    myPort.onMessage.addListener(function portListener(m) {
        if (m.cmd.includes("Text")) {
            self.record(m.cmd, tmpText, tmpVal);
        } else if (m.cmd.includes("Title")) {
            self.record(m.cmd, [[tmpTitle]], '');
        } else if (m.cmd.includes("Value")) {
            self.record(m.cmd, tmpText, getInputValue(eventTarget));
        } else if (m.cmd.includes('waitFor')) {
            self.record(m.cmd, tmpText, '');
        }
        myPort.onMessage.removeListener(portListener);
    });
}, true);
// END

// © Yun-Wen Lin, SideeX Team
var getEle;
var checkFocus = 0;
Recorder.addEventHandler('editContent', 'focus', function (event) {
    const eventTarget = getEventTarget(event);
    var editable = eventTarget.contentEditable;
    if (editable == 'true') {
        getEle = eventTarget;
        contentTest = getEle.innerHTML;
        checkFocus = 1;
    }
}, true);
// END

// © Yun-Wen Lin, SideeX Team
Recorder.addEventHandler('editContent', 'blur', function (event) {
    if (checkFocus == 1) {
        const eventTarget = getEventTarget(event);
        if (eventTarget == getEle) {
            if (getEle.innerHTML != contentTest) {
                this.record("editContent", this.locatorBuilders.buildAll(eventTarget), getEle.innerHTML);
            }
            checkFocus = 0;
        }
    }
}, true);
// END

browser.runtime.sendMessage({
    attachRecorderRequest: true
}).catch(function (reason) {
    // Failed silently if receiveing end does not exist
});

// Copyright 2005 Shinya Kasatani
Recorder.prototype.getOptionLocator = function (option) {
    var label = option.text.replace(/^ *(.*?) *$/, "$1");
    if (label.match(/\xA0/)) { // if the text contains &nbsp;
        return "label=regexp:" + label.replace(/[\(\)\[\]\\\^\$\*\+\?\.\|\{\}]/g, function (str) {
            return '\\' + str
        })
            .replace(/\s+/g, function (str) {
                if (str.match(/\xA0/)) {
                    if (str.length > 1) {
                        return "\\s+";
                    } else {
                        return "\\s";
                    }
                } else {
                    return str;
                }
            });
    } else {
        return "label=" + label;
    }
};

Recorder.prototype.findClickableElement = function (e) {
    if (!e.tagName) return null;
    var tagName = e.tagName.toLowerCase();
    var type = e.type;
    if (e.hasAttribute("onclick") || e.hasAttribute("href") || tagName == "button" ||
        (tagName == "input" &&
            (type == "submit" || type == "button" || type == "image" || type == "radio" || type == "checkbox" || type == "reset"))) {
        return e;
    } else {
        if (e.parentNode != null) {
            return this.findClickableElement(e.parentNode);
        } else {
            return null;
        }
    }
};

//select / addSelect / removeSelect
Recorder.addEventHandler('select', 'focus', function (event) {
    const eventTarget = getEventTarget(event);
    if (eventTarget.nodeName) {
        var tagName = eventTarget.nodeName.toLowerCase();
        if ('select' == tagName && eventTarget.multiple) {
            var options = eventTarget.options;
            for (var i = 0; i < options.length; i++) {
                if (options[i]._wasSelected == null) {
                    // is the focus was gained by mousedown event, _wasSelected would be already set
                    options[i]._wasSelected = options[i].selected;
                }
            }
        }
    }
}, true);

Recorder.addEventHandler('select', 'change', function (event) {
    const eventTarget = getEventTarget(event);
    if (eventTarget.tagName) {
        var tagName = eventTarget.tagName.toLowerCase();
        if ('select' == tagName) {
            if (!eventTarget.multiple) {
                var option = eventTarget.options[eventTarget.selectedIndex];
                this.record("select", this.locatorBuilders.buildAll(eventTarget), this.getOptionLocator(option));
            } else {
                var options = eventTarget.options;
                for (var i = 0; i < options.length; i++) {
                    if (options[i]._wasSelected == null) { }
                    if (options[i]._wasSelected != options[i].selected) {
                        var value = this.getOptionLocator(options[i]);
                        if (options[i].selected) {
                            this.record("addSelection", this.locatorBuilders.buildAll(eventTarget), value);
                        } else {
                            this.record("removeSelection", this.locatorBuilders.buildAll(eventTarget), value);
                        }
                        options[i]._wasSelected = options[i].selected;
                    }
                }
            }
        }
    }
});
