/**
 * SelectorsHub - Locator Tester (panel side)
 * -------------------------------------------------------------
 * Wires up the small "Test" button that sits before every copy button in
 * both the Standard locators tab and the Playwright tab, in both the
 * DevTools panel and the Side Panel.
 *
 * Clicking the button opens a tiny menu with two choices:
 *   - Click            -> performs a real click on the matched element
 *   - Type / SendKeys  -> types "selectorshub" (text fields) or "123456"
 *                         (numeric fields) into the matched element
 *
 * All the actual DOM resolution + action logic lives in the content-script
 * side (content-script/selector-tester.js). This file only builds the UI
 * and dispatches the request through the correct channel:
 *   - DevTools panel -> browserType.devtools.inspectedWindow.eval(...)
 *   - Side panel     -> postSafeMessage(...) -> background -> content script
 *
 * Exposed as window.ShubSelectorTest = { attachPw, initStandard }.
 */

(function () {
  "use strict";

  /* ---------------------------------------------------------------- *
   * Context detection + helpers
   * ---------------------------------------------------------------- */

  function isSidePanelContext() {
    try {
      return !(typeof browserType !== "undefined" && browserType.devtools);
    } catch (e) {
      return true;
    }
  }

  function b64Encode(str) {
    try {
      return btoa(unescape(encodeURIComponent(str)));
    } catch (e) {
      return btoa(str);
    }
  }

  // Statuses that mean an element was actually resolved. In the Side Panel the
  // request reaches every frame, so most frames answer "notfound" - a real
  // match must win over those, regardless of arrival order.
  function isResolvedStatus(s) {
    return s === "clicked" || s === "hovered" || s === "typed" || s === "nottypable" || s === "unsupported";
  }

  // Tracks the in-flight Side Panel request so multi-frame replies can be
  // reconciled (prefer a match; fall back to notfound only if none matches).
  var reqSeq = 0;
  var pending = null;

  /* ---------------------------------------------------------------- *
   * Dispatch an action to the content script
   * ---------------------------------------------------------------- */

  function dispatchTest(command, value, actionType, anchorEl) {
    var reqId = ++reqSeq;
    var sidePanel = isSidePanelContext();
    var payload = {
      command: command,
      value: value,
      actionType: actionType,
      frameHop: !sidePanel,
      reqId: reqId
    };

    if (sidePanel) {
      // Side Panel: route through the background page to the content script.
      // The message reaches every frame, so several replies come back; we
      // reconcile them in the result listener, preferring an actual match.
      if (typeof getActiveTabId !== "function" || typeof postSafeMessage !== "function") {
        showFeedback({ status: "error" }, anchorEl);
        return;
      }

      if (pending && pending.timer) clearTimeout(pending.timer);
      pending = {
        reqId: reqId,
        resolved: false,
        fallback: null,
        anchor: anchorEl,
        actionType: actionType,
        timer: null
      };

      showFeedback({ status: "pending", actionType: actionType }, anchorEl);

      getActiveTabId().then(function (tabId) {
        postSafeMessage({ name: "shub-test-locator", tabId: tabId, payload: payload });
      });

      // If no frame reports a match, show the fallback (notfound/error) after a
      // short window that lets the matching frame's reply win the race.
      pending.timer = setTimeout(function () {
        if (pending && pending.reqId === reqId && !pending.resolved) {
          pending.resolved = true;
          showFeedback(pending.fallback || { status: "notfound" }, pending.anchor);
        }
      }, 700);
      return;
    }

    // DevTools panel: call straight into the content-script world (single frame).
    try {
      var b64 = b64Encode(JSON.stringify(payload));
      browserType.devtools.inspectedWindow.eval(
        'shubTestLocatorFromPanel("' + b64 + '")',
        { useContentScriptContext: true },
        function (result, exceptionInfo) {
          var res = null;
          if (!exceptionInfo) {
            try { res = typeof result === "string" ? JSON.parse(result) : result; } catch (e) {}
          }
          if (!res) res = { status: "error" };
          showFeedback(res, anchorEl);
        }
      );
    } catch (e) {
      showFeedback({ status: "error" }, anchorEl);
    }
  }

  /* ---------------------------------------------------------------- *
   * Option menu (Click / Type-SendKeys)
   * ---------------------------------------------------------------- */

  var openMenuEl = null;

  function closeMenu() {
    if (openMenuEl && openMenuEl.parentNode) {
      openMenuEl.parentNode.removeChild(openMenuEl);
    }
    openMenuEl = null;
    document.removeEventListener("mousedown", onOutsideDown, true);
    document.removeEventListener("keydown", onMenuKey, true);
    window.removeEventListener("scroll", closeMenu, true);
    window.removeEventListener("resize", closeMenu, true);
  }

  function onOutsideDown(e) {
    if (openMenuEl && !openMenuEl.contains(e.target)) closeMenu();
  }

  function onMenuKey(e) {
    if (e.key === "Escape") closeMenu();
  }

  function openMenu(anchorEl, onChoose) {
    closeMenu();

    var menu = document.createElement("div");
    menu.className = "shub-test-menu";

    var clickItem = document.createElement("button");
    clickItem.className = "shub-test-menu-item";
    clickItem.type = "button";
    clickItem.textContent = "Click";

    var hoverItem = document.createElement("button");
    hoverItem.className = "shub-test-menu-item";
    hoverItem.type = "button";
    hoverItem.textContent = "Hover";

    var typeItem = document.createElement("button");
    typeItem.className = "shub-test-menu-item";
    typeItem.type = "button";
    typeItem.textContent = "Type / SendKeys";

    clickItem.addEventListener("click", function (e) {
      e.stopPropagation();
      closeMenu();
      onChoose("click");
    });
    hoverItem.addEventListener("click", function (e) {
      e.stopPropagation();
      closeMenu();
      onChoose("hover");
    });
    typeItem.addEventListener("click", function (e) {
      e.stopPropagation();
      closeMenu();
      onChoose("type");
    });

    menu.appendChild(clickItem);
    menu.appendChild(hoverItem);
    menu.appendChild(typeItem);
    document.body.appendChild(menu);

    // Position just below the button, kept within the viewport.
    var rect = anchorEl.getBoundingClientRect();
    var mw = menu.offsetWidth || 130;
    var mh = menu.offsetHeight || 56;
    var left = rect.left;
    var top = rect.bottom + 4;
    if (left + mw > window.innerWidth - 6) left = window.innerWidth - mw - 6;
    if (left < 6) left = 6;
    if (top + mh > window.innerHeight - 6) top = rect.top - mh - 4;
    menu.style.left = Math.round(left) + "px";
    menu.style.top = Math.round(Math.max(6, top)) + "px";

    openMenuEl = menu;
    setTimeout(function () {
      document.addEventListener("mousedown", onOutsideDown, true);
      document.addEventListener("keydown", onMenuKey, true);
      window.addEventListener("scroll", closeMenu, true);
      window.addEventListener("resize", closeMenu, true);
    }, 0);
  }

  /* ---------------------------------------------------------------- *
   * Feedback toast
   * ---------------------------------------------------------------- */

  var toastTimer = null;
  var lastAnchor = null;

  function messageFor(res) {
    switch (res && res.status) {
      case "pending":
        return {
          text: res.actionType === "type" ? "Typing\u2026"
              : (res.actionType === "hover" ? "Hovering\u2026" : "Clicking\u2026"),
          tone: "info"
        };
      case "clicked":
        return { text: "\u2713 Clicked the '" + (res.name || res.tag || "element") + "' element", tone: "ok" };
      case "hovered":
        return {
          text: "\u2713 Hovered the '" + (res.name || res.tag || "element") + "' element \u2014 pure-CSS menus may not react",
          tone: "ok"
        };
      case "typed":
        return {
          text: "\u2713 Typed \"" + res.value + "\" into the '" + (res.name || res.tag || "field") + "' element",
          tone: "ok"
        };
      case "nottypable":
        return { text: "\u26A0 This element doesn't accept text input", tone: "warn" };
      case "notfound":
        return { text: "\u26A0 No matching element found on the page", tone: "warn" };
      case "unsupported":
        return { text: "\u26A0 This locator type can't be tested directly", tone: "warn" };
      default:
        return { text: "\u26A0 Couldn't test this locator", tone: "warn" };
    }
  }

  function showFeedback(res, anchorEl) {
    if (anchorEl) lastAnchor = anchorEl;
    var info = messageFor(res);

    var toast = document.getElementById("shub-test-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "shub-test-toast";
      toast.className = "shub-test-toast";
      document.body.appendChild(toast);
    }
    toast.textContent = info.text;
    toast.setAttribute("data-tone", info.tone);

    var anchor = lastAnchor;
    if (anchor && anchor.getBoundingClientRect) {
      var rect = anchor.getBoundingClientRect();
      toast.style.top = Math.round(rect.bottom + 6) + "px";
      var left = rect.left;
      var tw = toast.offsetWidth || 180;
      if (left + tw > window.innerWidth - 6) left = window.innerWidth - tw - 6;
      if (left < 6) left = 6;
      toast.style.left = Math.round(left) + "px";
    }

    toast.classList.add("show");
    if (toastTimer) clearTimeout(toastTimer);
    // Keep the "…" pending toast until the real result arrives.
    if (res.status !== "pending") {
      toastTimer = setTimeout(function () {
        toast.classList.remove("show");
      }, 2600);
    }
  }

  /* ---------------------------------------------------------------- *
   * Standard tab wiring
   * ---------------------------------------------------------------- */

  function getStandardRowInfo(li) {
    var span = li.querySelector(".valueSelector");
    if (!span) return null;

    var command = span.getAttribute("data-command") || "";
    var value = "";

    // Prefer the clean raw-value attributes that some rows store, so the
    // driver-command wrapping in the visible text is bypassed.
    if (span.hasAttribute("css")) value = span.getAttribute("css");
    else if (span.hasAttribute("relXpath")) value = span.getAttribute("relXpath");
    else if (span.hasAttribute("absXpath")) value = span.getAttribute("absXpath");
    else if (span.hasAttribute("selector")) value = span.getAttribute("selector");
    else value = (span.innerText || span.textContent || "").trim();

    if (!value) return null;
    return { command: command, value: value };
  }

  function onStandardTestClick(e) {
    e.preventDefault();
    e.stopPropagation();
    var btn = e.currentTarget;
    var li = btn.closest(".selectorsRow");
    if (!li) return;

    openMenu(btn, function (actionType) {
      var info = getStandardRowInfo(li);
      if (!info) {
        showFeedback({ status: "notfound" }, btn);
        return;
      }
      dispatchTest(info.command, info.value, actionType, btn);
    });
  }

  function initStandard() {
    var buttons = document.querySelectorAll(".selectorsRow .shub-test-btn");
    for (var i = 0; i < buttons.length; i++) {
      if (buttons[i].getAttribute("data-shub-wired") === "1") continue;
      buttons[i].setAttribute("data-shub-wired", "1");
      buttons[i].addEventListener("click", onStandardTestClick);
    }
  }

  /* ---------------------------------------------------------------- *
   * Search-box wiring (user-written XPath / Playwright / CSS locator)
   * ---------------------------------------------------------------- */

  function initSearchBox() {
    var btn = document.querySelector(".shub-test-btn-header");
    if (!btn || btn.getAttribute("data-shub-wired") === "1") return;
    btn.setAttribute("data-shub-wired", "1");

    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      openMenu(btn, function (actionType) {
        var input = document.querySelector("#searchbox1") || document.querySelector(".jsSelector");
        var val = input ? (input.value || "").trim() : "";
        if (!val) {
          showFeedback({ status: "notfound" }, btn);
          return;
        }
        dispatchTest("searchbox", val, actionType, btn);
      });
    });
  }

  /* ---------------------------------------------------------------- *
   * Playwright tab wiring (rows are generated dynamically)
   * ---------------------------------------------------------------- */

  function attachPw(rowEl, selector) {
    if (!rowEl) return;
    var btn = rowEl.querySelector(".shub-test-btn");
    if (!btn || btn.getAttribute("data-shub-wired") === "1") return;
    btn.setAttribute("data-shub-wired", "1");

    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      openMenu(btn, function (actionType) {
        var sel = selector;
        if (sel && sel.trimStart && sel.trimStart().startsWith("await ")) {
          sel = sel.trimStart().replace(/^await\s+/, "");
        }
        dispatchTest("playwright", sel, actionType, btn);
      });
    });
  }

  /* ---------------------------------------------------------------- *
   * Result listener (Side Panel path)
   * ---------------------------------------------------------------- */

  try {
    chrome.runtime.onMessage.addListener(function (message) {
      if (!message || message.name !== "shub-test-locator-result") return;
      if (!pending) return; // no in-flight request (or DevTools path)

      // Ignore replies from a previous request.
      if (message.reqId != null && message.reqId !== pending.reqId) return;
      if (pending.resolved) return;

      var res = message.result || { status: "error" };

      if (isResolvedStatus(res.status)) {
        pending.resolved = true;
        if (pending.timer) clearTimeout(pending.timer);
        showFeedback(res, pending.anchor);
      } else if (!pending.fallback || pending.fallback.status === "notfound") {
        // Remember the best non-match reply (prefer error over notfound) in
        // case no frame ends up matching.
        pending.fallback = res;
      }
    });
  } catch (e) {}

  /* ---------------------------------------------------------------- *
   * Boot
   * ---------------------------------------------------------------- */

  function boot() {
    initStandard();
    initSearchBox();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  window.ShubSelectorTest = {
    attachPw: attachPw,
    initStandard: initStandard,
    initSearchBox: initSearchBox
  };
})();
