/**
 * Created by sanjay kumar on 25/05/2025.
 */


/**
 * Extract selector label from Playwright selector string
 * Returns the method name exactly as it appears in the selector
 * @returns {string} Extracted label
 */
function extractSelectorLabel(selector) {
    // Extract method name after 'page.' or 'Page.' (matches both JavaScript and C#)
    // Returns the method name in its original case (camelCase for JS, PascalCase for C#)
    const match = selector.match(/[Pp]age\.([\w]+)\(/);
    if (match) {
        return match[1];  // Return as-is to preserve language-specific naming convention
    }
    return 'selector';
}

/**
 * Escape HTML special characters
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Escape string for JavaScript
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeForJs(text) {
    return text.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/`/g, '\\`');
}

function displayPlaywrightSelectors(selectors) {
    const listContainer = document.getElementById('pw-selectorList');
    
    if (!selectors || selectors.length === 0) {
        listContainer.innerHTML = `
            <div class="empty-state">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <p>No selectors generated yet</p>
            </div>
        `;
        return;
    }

    // Add 'await' only if JS/TS is selected AND await toggle is on
    const langSelect = document.getElementById("langBtn");
    const selectedLang = langSelect ? langSelect.value : 'js';
    const awaitToggle = document.getElementById("awaitToggle");

    const isAwaitEnabled = awaitToggle ? awaitToggle.checked : false;

    if ((selectedLang === 'js' || selectedLang === 'ts' || selectedLang === 'csharp') && isAwaitEnabled) {
        selectors = addAwaitToSelectors(selectors);
    }

    listContainer.innerHTML = '';
    
    selectors.forEach((item, index) => {
        const selectorItem = document.createElement('div');
        selectorItem.className = 'pw-selector-item';
        
        // Determine badge class based on count
        let badgeClass = 'many';
        if (item.count === 1) {
            badgeClass = 'unique';
        } else if (item.count >= 2 && item.count <= 5) {
            badgeClass = 'few';
        }
        
        const codeClass = item.count === 1 ? 'unique' : '';
        const label = extractSelectorLabel(item.selector);
        
        selectorItem.innerHTML = `
            <button class="shub-test-btn" data-shub-test="1" title="测试此定位器 - 在匹配的元素上点击或输入"><img class="shub-test-icon" src="../icons/test.svg" alt="test"></button>
            <div class="pw-edit-icon-container">
                <button class="pw-edit-icon" title="点击编辑"></button>
            </div>
            <div class="pw-copy-icon-container">
                <button class="pw-copy-icon" title="复制到剪贴板">
                </button>
                <div class="pw-tooltip">Copied!</div>
            </div>
            <span class="pw-selector-count-badge ${badgeClass}">${item.count}</span>
            <span class="pw-selector-label">${label}</span>
            <code class="pw-selector-code ${codeClass}">${escapeHtml(item.selector)}</code>
        `;
        
        listContainer.appendChild(selectorItem);

        // Wire up the "测试此定位器" button (logic lives in selector-test.js)
        if (window.ShubSelectorTest) {
            window.ShubSelectorTest.attachPw(selectorItem, item.selector);
        }
        
        // Add click listener to copy button
        const copyButton = selectorItem.querySelector('.pw-copy-icon');
        const tooltip = selectorItem.querySelector('.pw-tooltip');
        const editButton = selectorItem.querySelector('.pw-edit-icon');
        const codeElement = selectorItem.querySelector('.pw-selector-code');

        codeElement.addEventListener('click', async () => {
          var selectorValue = item.selector;
          var inputBox = document.querySelector(".jsSelector");
          if(selectorValue.trimStart().startsWith("await ")) {
             selectorValue = selectorValue.trimStart().replace(/^await\s+/, "");
          }
          inputBox.value = selectorValue;
          inputBox.focus();
        });
        
        copyButton.addEventListener('click', async () => {
            try {
                
                var text = item.selector;

                  let textarea = document.createElement("textarea");
                  textarea.id = "t";
                  // Optional step to make less noise on the page, if any!
                  textarea.style.height = 0;
                  // Now append it to your page somewhere, I chose <body>
                  document.body.appendChild(textarea);
                  // Give our textarea a value of whatever inside the div of id=containerid
                  textarea.value = text;
                  // textarea.value = text.innerText == "" ? text.textContent : text.innerText;

                  // Now copy whatever inside the textarea to clipboard
                  let selector = document.querySelector("#t");
                  selector.select();
                  document.execCommand("copy");
                  // Remove the textarea
                  document.body.removeChild(textarea);
                
                //Show tooltip
                tooltip.classList.add('show');
                
                //Hide tooltip after 2 seconds
                setTimeout(() => {
                    tooltip.classList.remove('show');
                }, 2000);
            } catch (err) {
                console.error('复制文本失败：', err);
            }
        });

        editButton.addEventListener('click', async () => {
          var selectorValue = item.selector;
          if (selectorValue.startsWith("await ")) {
                selectorValue = selectorValue.replace(/^await\s+/, "");
            }
          var inputBox = document.querySelector(".jsSelector");
          inputBox.value = selectorValue;
          inputBox.focus();
        });

        document.querySelector(".pw-selector-item code").style.color = "#ff6b00";
        
    });
}



document.addEventListener("DOMContentLoaded", function () {
    chrome.storage.local.get("selectedbutton", (data) => {
        let savedType = data.selectedbutton;
        if (!savedType) {
            savedType = "standard";
            chrome.storage.local.set({ selectedbutton: "standard" });
        }

        if (savedType === "playwright") {
            const playwrightBtn = document.getElementById('playwrightBtn');
            const standardBtn = document.getElementById('standardBtn');

            playwrightBtn.classList.remove('active');
            standardBtn.classList.remove('active');

            let standardSelectors = document.querySelector(".selectorsGenerator");
            let pwSelectors = document.querySelector(".pw-container");
            let menuContainer = document.querySelector(".menu__container");
            let configOptions = document.querySelector(".configOptions");
            let configRow = document.querySelector(".cta-row");

            playwrightBtn.classList.add('active');
            selectedType = 'playwright';
            standardSelectors.style.display = "none";
            pwSelectors.style.display = "block";
            if (menuContainer) {
                menuContainer.style.display = "none";
            }
            configOptions.style.visibility = "hidden";
            configRow.style.display = "none";
            setTimeout(() => {
                let configOptions = document.querySelector(".configOptions");
                configOptions.style.visibility = "hidden";
            }, 300);
        }
    });

    let awaitCheck = document.querySelector(".await-check");

    // Load selected language for playwright
    const langSelect = document.getElementById("langBtn");
    const isPlaywrightBtn = document.getElementById("playwrightBtn");
    chrome.storage.local.get("selectedLanguage", (data) => {
        if (data.selectedLanguage) {
            langSelect.value = data.selectedLanguage;
            if((langSelect.value==="js" || langSelect.value==="csharp") && isPlaywrightBtn.classList.contains("active")){
                awaitCheck.style.display = "inline-flex";
            }else{
                awaitCheck.style.display = "none";
            }
        }
    });
    
    langSelect.addEventListener("change", function () {
        generateSelectors();
        const selected = this.value;
        chrome.storage.local.set({ selectedLanguage: selected });
        if((langSelect.value==="js" || langSelect.value==="csharp") && isPlaywrightBtn.classList.contains("active")){
            awaitCheck.style.display = "inline-flex";
        }else{
            awaitCheck.style.display = "none";
        }
    });

      // Load and setup await toggle
    const awaitToggle = document.getElementById("awaitToggle");
    chrome.storage.local.get("awaitEnabled", (data) => {
        if (typeof data.awaitEnabled != "undefined") {
            awaitToggle.checked = data.awaitEnabled;
        }
    });

    awaitToggle.addEventListener("change", function () {

        if(window.location.href.includes("side-panel/side-shub-panel.html")){
            $('code.pw-selector-code').text(function(i, text) {
                if (text.trimStart().startsWith("await ")) { 
                    return text.trimStart().replace(/^await\s+/, "");
                }else{ 
                    return "await " + text;
                }
            });
        }else{
            generateSelectors();
        }

        chrome.storage.local.set({ awaitEnabled: this.checked });
    });

})



/**
 * Convert single quotes to double quotes in Playwright selector
 * @param {string} selector - Playwright selector string
 * @returns {string} Selector with double quotes
 */
function convertToDoubleQuotes(selector) {
    // Match the pattern: page.method('arg1', { key: 'value' })
    // We need to replace single quotes with double quotes while preserving escaped quotes
    
    return selector.replace(/page\.(\w+)\((.*)\)$/, (match, method, args) => {
        // Replace single quotes with double quotes in the arguments
        // Handle nested quotes carefully
        const convertedArgs = args
            .replace(/\\'/g, '\u0000') // Temporarily replace escaped single quotes
            .replace(/'/g, '"')         // Replace all single quotes with double quotes
            .replace(/\u0000/g, "\\'"); // Restore escaped single quotes
        
        return `page.${method}(${convertedArgs})`;
    });
}

/**
 * Convert all selectors in array from single quotes to double quotes
 * @param {Array} selectors - Array of selector objects with {selector, count}
 * @returns {Array} Array with converted selectors
 */
function convertSelectorsToDoubleQuotes(selectors) {
    if (!selectors || !Array.isArray(selectors)) {
        return selectors;
    }
    
    return selectors.map(item => ({
        ...item,
        selector: convertToDoubleQuotes(item.selector)
    }));
}



/**
 * Convert Playwright selector from JavaScript to Python format
 * @param {string} selector - Playwright selector string in JavaScript format
 * @returns {string} Selector in Python format
 */
function convertToPythonPlaywright(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }
    
    // Extract method and arguments
    const methodMatch = selector.match(/page\.(\w+)\((.*)\)$/s);
    if (!methodMatch) {
        return selector;
    }
    
    const method = methodMatch[1];
    let args = methodMatch[2].trim();
    
    // Convert camelCase method name to snake_case
    const pythonMethod = method.replace(/([A-Z])/g, '_$1').toLowerCase();
    
    // Special handling for locator, xpath, css, frame_locator - they use raw selectors
    if (method === 'locator' || method === 'xpath' || method === 'css' || method === 'frameLocator') {
        const singleQuoteMatch = args.match(/^'(.*)'$/s);
        if (singleQuoteMatch) {
            const content = singleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `page.${pythonMethod}("${convertedContent}")`;
        }
        
        const doubleQuoteMatch = args.match(/^"(.*)"$/s);
        if (doubleQuoteMatch) {
            const content = doubleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `page.${pythonMethod}("${convertedContent}")`;
        }
        
        return `page.${pythonMethod}(${args})`;
    }
    
    // Check if there are options
    const hasOptions = /\{[^}]+\}/.test(args);
    
    if (!hasOptions) {
        // Simple case: just convert quotes and method name
        return `page.${pythonMethod}(${args.replace(/'/g, '"')})`;
    }
    
    // Complex case: parse arguments and options
    const complexMatch = args.match(/^(['"])([^'"]+)\1\s*,\s*\{([^}]+)\}$/);
    
    if (!complexMatch) {
        return `page.${pythonMethod}(${args.replace(/'/g, '"')})`;
    }
    
    const mainArg = complexMatch[2];
    const optionsStr = complexMatch[3].trim();
    
    // Parse and convert options
    const pythonKwargs = [];
    let currentOption = '';
    let inString = false;
    let stringChar = '';
    
    for (let i = 0; i < optionsStr.length; i++) {
        const char = optionsStr[i];
        const prevChar = i > 0 ? optionsStr[i - 1] : '';
        
        if ((char === '"' || char === "'") && prevChar !== '\\') {
            if (!inString) {
                inString = true;
                stringChar = char;
            } else if (char === stringChar) {
                inString = false;
            }
        }
        
        if (char === ',' && !inString) {
            if (currentOption.trim()) {
                pythonKwargs.push(convertPythonOption(currentOption.trim()));
            }
            currentOption = '';
        } else {
            currentOption += char;
        }
    }
    
    if (currentOption.trim()) {
        pythonKwargs.push(convertPythonOption(currentOption.trim()));
    }
    
    const validKwargs = pythonKwargs.filter(kwarg => kwarg && kwarg.length > 0);
    
    // Build Python selector
    if (validKwargs.length > 0) {
        return `page.${pythonMethod}("${mainArg}", ${validKwargs.join(', ')})`;
    } else {
        return `page.${pythonMethod}("${mainArg}")`;
    }
}

/**
 * Convert chained Playwright selector from JavaScript to Python format
 * @param {string} selector - Playwright selector string with potential chaining
 * @returns {string} Python-formatted selector with chaining
 */
function convertToPythonPlaywrightWithChaining(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }
    
    let convertedSelector = '';
    let remaining = selector;
    
    // Process each method in the chain
    while (remaining) {
        // Check if it's the first method (page.method)
        const pageMethodMatch = remaining.match(/^page\.(\w+)\(([^)]*)\)/);
        if (pageMethodMatch) {
            const [fullMatch, method, args] = pageMethodMatch;
            convertedSelector += convertSinglePythonMethod('page.' + method, args.trim());
            remaining = remaining.substring(fullMatch.length);
            continue;
        }
        
        // Match chained method: .method(args)
        const methodMatch = remaining.match(/^\.(\w+)\(([^)]*)\)/);
        if (methodMatch) {
            const [fullMatch, method, args] = methodMatch;
            convertedSelector += '.' + convertSinglePythonMethod(method, args.trim());
            remaining = remaining.substring(fullMatch.length);
        } else {
            break;
        }
    }
    
    return convertedSelector || selector;
}

/**
 * Convert a single method call for Python (helper function)
 * @param {string} method - Method name (with or without 'page.')
 * @param {string} args - Arguments string
 * @returns {string} Converted method call
 */
function convertSinglePythonMethod(method, args) {
    const isPageMethod = method.startsWith('page.');
    const actualMethod = isPageMethod ? method.substring(5) : method;
    
    // Convert camelCase to snake_case
    const pythonMethod = actualMethod.replace(/([A-Z])/g, '_$1').toLowerCase();
    const prefix = isPageMethod ? 'page.' : '';
    
    // Special handling for locator, xpath, css, frame_locator
    if (actualMethod === 'locator' || actualMethod === 'xpath' || actualMethod === 'css' || actualMethod === 'frameLocator') {
        const singleQuoteMatch = args.match(/^'(.*)'$/s);
        if (singleQuoteMatch) {
            const content = singleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `${prefix}${pythonMethod}("${convertedContent}")`;
        }
        
        const doubleQuoteMatch = args.match(/^"(.*)"$/s);
        if (doubleQuoteMatch) {
            const content = doubleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `${prefix}${pythonMethod}("${convertedContent}")`;
        }
        
        return `${prefix}${pythonMethod}(${args})`;
    }
    
    // Handle filter method with options object
    if (actualMethod === 'filter') {
        return convertPythonFilterMethod(args);
    }
    
    // Handle first, last, nth methods
    if (actualMethod === 'first' || actualMethod === 'last') {
        return `${pythonMethod}()`;
    }
    
    if (actualMethod === 'nth') {
        return `nth(${args})`;
    }
    
    // Check if there are options
    const hasOptions = /\{[^}]+\}/.test(args);
    
    if (!hasOptions) {
        // Simple case: convert quotes and method name
        return `${prefix}${pythonMethod}(${args.replace(/'/g, '"')})`;
    }
    
    // Complex case: parse arguments and options
    // Use a more flexible regex that captures the main argument and options separately
    const complexMatch = args.match(/^(['"])([^'"]+)\1\s*,\s*\{([^}]+)\}$/);
    
    if (!complexMatch) {
        return `${prefix}${pythonMethod}(${args.replace(/'/g, '"')})`;
    }
    
    const mainArg = complexMatch[2];
    const optionsStr = complexMatch[3].trim();
    
    // Parse options more carefully
    const pythonKwargs = [];
    
    // Split by comma, but be careful about nested structures
    let currentOption = '';
    let depth = 0;
    let inString = false;
    let stringChar = '';
    
    for (let i = 0; i < optionsStr.length; i++) {
        const char = optionsStr[i];
        const prevChar = i > 0 ? optionsStr[i - 1] : '';
        
        // Track string boundaries
        if ((char === '"' || char === "'") && prevChar !== '\\') {
            if (!inString) {
                inString = true;
                stringChar = char;
            } else if (char === stringChar) {
                inString = false;
            }
        }
        
        // Track depth for nested objects
        if (!inString) {
            if (char === '{' || char === '[') depth++;
            if (char === '}' || char === ']') depth--;
        }
        
        // Split on comma only at depth 0 and outside strings
        if (char === ',' && depth === 0 && !inString) {
            if (currentOption.trim()) {
                pythonKwargs.push(convertPythonOption(currentOption.trim()));
            }
            currentOption = '';
        } else {
            currentOption += char;
        }
    }
    
    // Don't forget the last option
    if (currentOption.trim()) {
        pythonKwargs.push(convertPythonOption(currentOption.trim()));
    }
    
    // Filter out empty strings
    const validKwargs = pythonKwargs.filter(kwarg => kwarg && kwarg.length > 0);
    
    // Build Python method call
    if (validKwargs.length > 0) {
        return `${prefix}${pythonMethod}("${mainArg}", ${validKwargs.join(', ')})`;
    } else {
        return `${prefix}${pythonMethod}("${mainArg}")`;
    }
}

/**
 * Convert a single Python option (key: value pair)
 * @param {string} option - Option string like "exact: true"
 * @returns {string} Python kwarg like "exact=True"
 */
function convertPythonOption(option) {
    // Try to match string values: key: 'value' or key: "value"
    const stringMatch = option.match(/^(\w+)\s*:\s*(['"])([^'"]*)\2$/);
    if (stringMatch) {
        const [, key, , value] = stringMatch;
        return `${key}="${value}"`;
    }
    
    // Try to match boolean values: key: true or key: false
    const boolMatch = option.match(/^(\w+)\s*:\s*(true|false)$/i);
    if (boolMatch) {
        const [, key, value] = boolMatch;
        // Convert JavaScript boolean to Python boolean
        const pythonValue = value.toLowerCase() === 'true' ? 'True' : 'False';
        return `${key}=${pythonValue}`;
    }
    
    // Try to match numeric values: key: 123
    const numMatch = option.match(/^(\w+)\s*:\s*(\d+)$/);
    if (numMatch) {
        const [, key, value] = numMatch;
        return `${key}=${value}`;
    }
    
    // Try to match regex patterns: key: /pattern/flags
    const regexMatch = option.match(/^(\w+)\s*:\s*\/(.+?)\/([gimsuy]*)$/);
    if (regexMatch) {
        const [, key, pattern, flags] = regexMatch;
        // Python uses re module, but for simple cases just use string
        return `${key}=re.compile(r"${pattern}"${flags ? ', ' + convertRegexFlags(flags) : ''})`;
    }
    
    // If nothing matches, return empty string
    return '';
}

/**
 * Convert regex flags from JavaScript to Python
 * @param {string} flags - JavaScript regex flags
 * @returns {string} Python regex flags
 */
function convertRegexFlags(flags) {
    const flagMap = {
        'i': 're.IGNORECASE',
        'm': 're.MULTILINE',
        's': 're.DOTALL',
        'g': '' // Python doesn't have global flag
    };
    
    return flags.split('')
        .map(f => flagMap[f] || '')
        .filter(Boolean)
        .join(' | ');
}

/**
 * Convert filter method with options for Python
 * @param {string} args - Arguments for filter method
 * @returns {string} Python-formatted filter method
 */
function convertPythonFilterMethod(args) {
    // Match object pattern: { hasText: 'value' } or { has: page.locator('...') }
    const objectMatch = args.match(/^\{([^}]+)\}$/);
    
    if (!objectMatch) {
        return `filter(${args.replace(/'/g, '"')})`;
    }
    
    const content = objectMatch[1].trim();
    
    // Check for hasText (Python uses has_text)
    const hasTextMatch = content.match(/hasText:\s*(['"])([^'"]+)\1/);
    if (hasTextMatch) {
        const text = hasTextMatch[2];
        return `filter(has_text="${text}")`;
    }
    
    // Check for has with locator
    const hasLocatorMatch = content.match(/has:\s*(page\.locator\([^)]+\))/);
    if (hasLocatorMatch) {
        const locator = hasLocatorMatch[1];
        const convertedLocator = convertToPythonPlaywrightWithChaining(locator);
        return `filter(has=${convertedLocator})`;
    }
    
    // Check for hasNot (Python uses has_not)
    const hasNotMatch = content.match(/hasNot:\s*(page\.locator\([^)]+\))/);
    if (hasNotMatch) {
        const locator = hasNotMatch[1];
        const convertedLocator = convertToPythonPlaywrightWithChaining(locator);
        return `filter(has_not=${convertedLocator})`;
    }
    
    return `filter(${args.replace(/'/g, '"')})`;
}

/**
 * Parse options string into array of key-value pairs
 * @param {string} optionsStr - Options string
 * @returns {Array} Array of option pairs
 */
function parseOptions(optionsStr) {
    const optionPairs = [];
    let current = '';
    let inQuote = false;
    let quoteChar = '';
    
    for (let i = 0; i < optionsStr.length; i++) {
        const char = optionsStr[i];
        const prevChar = i > 0 ? optionsStr[i - 1] : '';
        
        if ((char === '"' || char === "'") && prevChar !== '\\') {
            if (!inQuote) {
                inQuote = true;
                quoteChar = char;
            } else if (char === quoteChar) {
                inQuote = false;
            }
        }
        
        if (char === ',' && !inQuote) {
            optionPairs.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }
    
    if (current.trim()) {
        optionPairs.push(current.trim());
    }
    
    return optionPairs;
}

/**
 * Advanced Python conversion with chaining support
 * @param {string} selector - Playwright selector string
 * @returns {string} Python-formatted selector
 */
function convertToPythonPlaywrightAdvanced(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }
    
    // Check if selector has chaining (contains multiple method calls)
    const hasChaining = (selector.match(/\)\./g) || []).length > 0;
    
    if (hasChaining) {
        return convertToPythonPlaywrightWithChaining(selector);
    }
    
    // Original logic for non-chained selectors
    return convertToPythonPlaywright(selector);
}

/**
 * Convert all selectors in array to Python Playwright format
 * @param {Array} selectors - Array of selector objects with {selector, count}
 * @returns {Array} Array with Python-formatted selectors
 */
function convertSelectorsToPythonPlaywright(selectors) {
    if (!selectors || !Array.isArray(selectors)) {
        return selectors;
    }
    
    return selectors.map(item => ({
        ...item,
        selector: convertToPythonPlaywrightAdvanced(item.selector)
    }));
}


/**
 * Convert Playwright selector from JavaScript to Java format
 * @param {string} selector - Playwright selector string in JavaScript format
 * @returns {string} Selector in Java format
 */
function convertToJavaPlaywright(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }
    
    // Extract method and arguments
    const methodMatch = selector.match(/page\.(\w+)\((.*)\)$/s);
    if (!methodMatch) {
        return selector;
    }
    
    const method = methodMatch[1];
    let args = methodMatch[2].trim();
    
    // Special handling for locator, xpath, css methods - they use raw selectors
    if (method === 'locator' || method === 'xpath' || method === 'css' || method === 'frameLocator') {
        // Just convert single quotes to double quotes, no other transformation needed
        return `page.${method}(${args.replace(/'/g, '"')})`;
    }
    
    // Check if there are options
    const hasOptions = /\{[^}]+\}/.test(args);
    
    if (!hasOptions) {
        // Simple case: just convert quotes
        return `page.${method}(${args.replace(/'/g, '"')})`;
    }
    
    // Complex case: parse arguments and options for getBy* methods
    // Match: 'mainArg', { option: 'value', option2: 'value2' }
    const complexMatch = args.match(/^(['"])([^'"]+)\1\s*,\s*\{([^}]+)\}/);
    
    if (!complexMatch) {
        return `page.${method}(${args.replace(/'/g, '"')})`;
    }
    
    const mainArg = complexMatch[2];
    const optionsStr = complexMatch[3];
    
    // Parse options
    const optionPairs = [];
    let current = '';
    let inQuote = false;
    let quoteChar = '';
    
    for (let i = 0; i < optionsStr.length; i++) {
        const char = optionsStr[i];
        const prevChar = i > 0 ? optionsStr[i - 1] : '';
        
        if ((char === '"' || char === "'") && prevChar !== '\\') {
            if (!inQuote) {
                inQuote = true;
                quoteChar = char;
            } else if (char === quoteChar) {
                inQuote = false;
            }
        }
        
        if (char === ',' && !inQuote) {
            optionPairs.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }
    
    if (current.trim()) {
        optionPairs.push(current.trim());
    }
    
    // Convert options to Java builder pattern
    const javaOptions = optionPairs.map(pair => {
        const match = pair.match(/(\w+):\s*(['"])([^'"]*)\2/);
        if (match) {
            const [, key, , value] = match;
            const methodName = 'set' + key.charAt(0).toUpperCase() + key.slice(1);
            const escapedValue = value.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
            return `.${methodName}("${escapedValue}")`;
        }
        return '';
    }).filter(Boolean).join('');
    
    // Build final Java selector based on method type
    let result;
    
    switch (method) {
        case 'getByRole':
            const roleEnum = mainArg
                .replace(/([a-z])([A-Z])/g, '$1_$2')
                .toUpperCase();
            result = `page.getByRole(AriaRole.${roleEnum}${javaOptions})`;
            break;
            
        case 'getByLabel':
        case 'getByPlaceholder':
        case 'getByText':
        case 'getByTitle':
        case 'getByAltText':
            result = `page.${method}("${mainArg}"${javaOptions})`;
            break;
            
        case 'getByTestId':
            result = `page.getByTestId("${mainArg}")`;
            break;
            
        default:
            result = `page.${method}("${mainArg}"${javaOptions})`;
    }
    
    return result;
}

/**
 * Convert Playwright selector from JavaScript to Java format
 * @param {string} selector - Playwright selector string in JavaScript format
 * @returns {string} Selector in Java format
 */
function convertToJavaPlaywright(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }
    
    // Extract method and arguments
    const methodMatch = selector.match(/page\.(\w+)\((.*)\)$/s);
    if (!methodMatch) {
        return selector;
    }
    
    const method = methodMatch[1];
    let args = methodMatch[2].trim();
    
    // Special handling for locator, xpath, css, frameLocator - they use raw selectors
    if (method === 'locator' || method === 'xpath' || method === 'css' || method === 'frameLocator') {
        // Check if wrapped in single quotes
        const singleQuoteMatch = args.match(/^'(.*)'$/s);
        if (singleQuoteMatch) {
            const content = singleQuoteMatch[1];
            // Convert any internal double quotes to single quotes
            const convertedContent = content.replace(/"/g, "'");
            return `page.${method}("${convertedContent}")`;
        }
        
        // Check if wrapped in double quotes
        const doubleQuoteMatch = args.match(/^"(.*)"$/s);
        if (doubleQuoteMatch) {
            const content = doubleQuoteMatch[1];
            // Convert any internal double quotes to single quotes
            const convertedContent = content.replace(/"/g, "'");
            return `page.${method}("${convertedContent}")`;
        }
        
        // No quotes, return as-is
        return `page.${method}(${args})`;
    }
    
    // Check if there are options (for getBy* methods)
    const hasOptions = /\{[^}]+\}/.test(args);
    
    if (!hasOptions) {
        // Simple case: just convert quotes
        return `page.${method}(${args.replace(/'/g, '"')})`;
    }
    
    // Complex case: parse arguments and options
    const complexMatch = args.match(/^(['"])([^'"]+)\1\s*,\s*\{([^}]+)\}/);
    
    if (!complexMatch) {
        return `page.${method}(${args.replace(/'/g, '"')})`;
    }
    
    const mainArg = complexMatch[2];
    const optionsStr = complexMatch[3];
    
    // Parse options
    const optionPairs = [];
    let current = '';
    let inQuote = false;
    let quoteChar = '';
    
    for (let i = 0; i < optionsStr.length; i++) {
        const char = optionsStr[i];
        const prevChar = i > 0 ? optionsStr[i - 1] : '';
        
        if ((char === '"' || char === "'") && prevChar !== '\\') {
            if (!inQuote) {
                inQuote = true;
                quoteChar = char;
            } else if (char === quoteChar) {
                inQuote = false;
            }
        }
        
        if (char === ',' && !inQuote) {
            optionPairs.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }
    
    if (current.trim()) {
        optionPairs.push(current.trim());
    }
    
    // Convert options to Java builder pattern
    const javaOptions = optionPairs.map(pair => {
        const match = pair.match(/(\w+):\s*(['"])([^'"]*)\2/);
        if (match) {
            const [, key, , value] = match;
            const methodName = 'set' + key.charAt(0).toUpperCase() + key.slice(1);
            return `.${methodName}("${value}")`;
        }
        return '';
    }).filter(Boolean).join('');
    
    // Build final Java selector based on method type
    let result;
    
    switch (method) {
        case 'getByRole':
            const roleEnum = mainArg
                .replace(/([a-z])([A-Z])/g, '$1_$2')
                .toUpperCase();
            result = `page.getByRole(AriaRole.${roleEnum}${javaOptions})`;
            break;
            
        case 'getByLabel':
        case 'getByPlaceholder':
        case 'getByText':
        case 'getByTitle':
        case 'getByAltText':
            result = `page.${method}("${mainArg}"${javaOptions})`;
            break;
            
        case 'getByTestId':
            result = `page.getByTestId("${mainArg}")`;
            break;
            
        default:
            result = `page.${method}("${mainArg}"${javaOptions})`;
    }
    
    return result;
}

/**
 * Convert chained Playwright selector from JavaScript to Java format
 * @param {string} selector - Playwright selector string with potential chaining
 * @returns {string} Java-formatted selector with chaining
 */
function convertToJavaPlaywrightWithChaining(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }
    
    // Split by method calls while preserving the chain
    // Match pattern: page.method().method().method()
    let result = selector;
    
    // First, handle the initial page.method() call
    const firstMethodMatch = result.match(/^(page\.(\w+)\([^)]*\))/);
    if (!firstMethodMatch) {
        return selector;
    }
    
    let convertedSelector = '';
    let remaining = result;
    
    // Process each method in the chain
    while (remaining) {
        // Match: method(args)
        const methodMatch = remaining.match(/^\.?(\w+)\(([^)]*)\)/);
        
        if (!methodMatch) {
            // Check if it's the first method (page.method)
            const pageMethodMatch = remaining.match(/^page\.(\w+)\(([^)]*)\)/);
            if (pageMethodMatch) {
                const [fullMatch, method, args] = pageMethodMatch;
                convertedSelector += convertSingleMethod('page.' + method, args.trim());
                remaining = remaining.substring(fullMatch.length);
            } else {
                break;
            }
        } else {
            const [fullMatch, method, args] = methodMatch;
            convertedSelector += '.' + convertSingleMethod(method, args.trim());
            remaining = remaining.substring(fullMatch.length);
        }
    }
    
    return convertedSelector || selector;
}

/**
 * Convert a single method call (helper function)
 * @param {string} method - Method name (with or without 'page.')
 * @param {string} args - Arguments string
 * @returns {string} Converted method call
 */
function convertSingleMethod(method, args) {
    const isPageMethod = method.startsWith('page.');
    const actualMethod = isPageMethod ? method.substring(5) : method;
    const prefix = isPageMethod ? 'page.' : '';
    
    // Special handling for locator, xpath, css, frameLocator
    if (actualMethod === 'locator' || actualMethod === 'xpath' || actualMethod === 'css' || actualMethod === 'frameLocator') {
        const singleQuoteMatch = args.match(/^'(.*)'$/s);
        if (singleQuoteMatch) {
            const content = singleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `${prefix}${actualMethod}("${convertedContent}")`;
        }
        
        const doubleQuoteMatch = args.match(/^"(.*)"$/s);
        if (doubleQuoteMatch) {
            const content = doubleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `${prefix}${actualMethod}("${convertedContent}")`;
        }
        
        return `${prefix}${actualMethod}(${args})`;
    }
    
    // Handle filter method with options object
    if (actualMethod === 'filter') {
        return convertFilterMethod(args);
    }
    
    // Handle first, last, nth methods
    if (actualMethod === 'first' || actualMethod === 'last') {
        return `${actualMethod}()`;
    }
    
    if (actualMethod === 'nth') {
        return `nth(${args})`;
    }
    
    // Check if there are options
    const hasOptions = /\{[^}]+\}/.test(args);
    
    if (!hasOptions) {
        // Simple case: just convert quotes
        return `${prefix}${actualMethod}(${args.replace(/'/g, '"')})`;
    }
    
    // Complex case: parse arguments and options for getBy* methods
    const complexMatch = args.match(/^(['"])([^'"]+)\1\s*,\s*\{([^}]+)\}/);
    
    if (!complexMatch) {
        return `${prefix}${actualMethod}(${args.replace(/'/g, '"')})`;
    }
    
    const mainArg = complexMatch[2];
    const optionsStr = complexMatch[3];
    
    // Parse options
    const optionPairs = parseOptions(optionsStr);
    
    // Convert options to Java builder pattern
    const javaOptions = optionPairs.map(pair => {
        // Match string values
        const stringMatch = pair.match(/(\w+):\s*(['"])([^'"]*)\2/);
        if (stringMatch) {
            const [, key, , value] = stringMatch;
            const methodName = 'set' + key.charAt(0).toUpperCase() + key.slice(1);
            return `.${methodName}("${value}")`;
        }
        
        // Match boolean values
        const boolMatch = pair.match(/(\w+):\s*(true|false)/);
        if (boolMatch) {
            const [, key, value] = boolMatch;
            const methodName = 'set' + key.charAt(0).toUpperCase() + key.slice(1);
            return `.${methodName}(${value})`;
        }
        
        // Match numeric values
        const numMatch = pair.match(/(\w+):\s*(\d+)/);
        if (numMatch) {
            const [, key, value] = numMatch;
            const methodName = 'set' + key.charAt(0).toUpperCase() + key.slice(1);
            return `.${methodName}(${value})`;
        }
        
        return '';
    }).filter(Boolean).join('');
    
    // Build method call based on method type
    if (actualMethod === 'getByRole') {
        const roleEnum = mainArg.replace(/([a-z])([A-Z])/g, '$1_$2').toUpperCase();
        return `${prefix}getByRole(AriaRole.${roleEnum}${javaOptions})`;
    } else if (['getByLabel', 'getByPlaceholder', 'getByText', 'getByTitle', 'getByAltText'].includes(actualMethod)) {
        // Build Java options class if needed
        if (javaOptions) {
            const optionsClass = getJavaOptionsClass(actualMethod);
            return `${prefix}${actualMethod}("${mainArg}", new ${optionsClass}()${javaOptions})`;
        }
        return `${prefix}${actualMethod}("${mainArg}")`;
    } else if (actualMethod === 'getByTestId') {
        return `${prefix}getByTestId("${mainArg}")`;
    } else {
        return `${prefix}${actualMethod}("${mainArg}"${javaOptions})`;
    }
}

/**
 * Get the Java options class name for a method
 * @param {string} method - Method name
 * @returns {string} Java options class name
 */
function getJavaOptionsClass(method) {
    const classMap = {
        'getByText': 'Page.GetByTextOptions',
        'getByLabel': 'Page.GetByLabelOptions',
        'getByPlaceholder': 'Page.GetByPlaceholderOptions',
        'getByTitle': 'Page.GetByTitleOptions',
        'getByAltText': 'Page.GetByAltTextOptions'
    };
    return classMap[method] || 'Page.GetByTextOptions';
}


/**
 * Convert filter method with options
 * @param {string} args - Arguments for filter method
 * @returns {string} Java-formatted filter method
 */
function convertFilterMethod(args) {
    // Match object pattern: { hasText: 'value' } or { has: page.locator('...') }
    const objectMatch = args.match(/^\{([^}]+)\}$/);
    
    if (!objectMatch) {
        return `filter(${args.replace(/'/g, '"')})`;
    }
    
    const content = objectMatch[1].trim();
    
    // Check for hasText
    const hasTextMatch = content.match(/hasText:\s*(['"])([^'"]+)\1/);
    if (hasTextMatch) {
        const text = hasTextMatch[2];
        return `filter(new Locator.FilterOptions().setHasText("${text}"))`;
    }
    
    // Check for has with locator
    const hasLocatorMatch = content.match(/has:\s*(page\.locator\([^)]+\))/);
    if (hasLocatorMatch) {
        const locator = hasLocatorMatch[1];
        const convertedLocator = convertToJavaPlaywrightWithChaining(locator);
        return `filter(new Locator.FilterOptions().setHas(${convertedLocator}))`;
    }
    
    // Check for hasNot
    const hasNotMatch = content.match(/hasNot:\s*(page\.locator\([^)]+\))/);
    if (hasNotMatch) {
        const locator = hasNotMatch[1];
        const convertedLocator = convertToJavaPlaywrightWithChaining(locator);
        return `filter(new Locator.FilterOptions().setHasNot(${convertedLocator}))`;
    }
    
    return `filter(${args.replace(/'/g, '"')})`;
}

/**
 * Parse options string into array of key-value pairs
 * @param {string} optionsStr - Options string
 * @returns {Array} Array of option pairs
 */
function parseOptions(optionsStr) {
    const optionPairs = [];
    let current = '';
    let inQuote = false;
    let quoteChar = '';
    
    for (let i = 0; i < optionsStr.length; i++) {
        const char = optionsStr[i];
        const prevChar = i > 0 ? optionsStr[i - 1] : '';
        
        if ((char === '"' || char === "'") && prevChar !== '\\') {
            if (!inQuote) {
                inQuote = true;
                quoteChar = char;
            } else if (char === quoteChar) {
                inQuote = false;
            }
        }
        
        if (char === ',' && !inQuote) {
            optionPairs.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }
    
    if (current.trim()) {
        optionPairs.push(current.trim());
    }
    
    return optionPairs;
}

/**
 * Advanced Java conversion with chaining support
 * @param {string} selector - Playwright selector string
 * @returns {string} Java-formatted selector
 */
function convertToJavaPlaywrightAdvanced(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }
    
    // Check if selector has chaining (contains multiple method calls)
    const hasChaining = (selector.match(/\)\./g) || []).length > 0;
    
    if (hasChaining) {
        return convertToJavaPlaywrightWithChaining(selector);
    }
    
    // Original logic for non-chained selectors
    const methodMatch = selector.match(/page\.(\w+)\((.*)\)$/s);
    if (!methodMatch) {
        return selector;
    }
    
    const method = methodMatch[1];
    let args = methodMatch[2].trim();
    
    return convertSingleMethod('page.' + method, args);
}

/**
 * Convert all selectors in array to Java Playwright format
 * @param {Array} selectors - Array of selector objects with {selector, count}
 * @returns {Array} Array with Java-formatted selectors
 */
function convertSelectorsToJavaPlaywright(selectors) {
    if (!selectors || !Array.isArray(selectors)) {
        return selectors;
    }
    
    return selectors.map(item => ({
        ...item,
        selector: convertToJavaPlaywrightAdvanced(item.selector)
    }));
}

/**
 * Add 'await' keyword to Playwright selectors for JS/TS language
 * @param {Array} selectors - Array of selector objects with {selector, count}
 * @returns {Array} Array with 'await' prefixed selectors
 */
function addAwaitToSelectors(selectors) {
    if (!selectors || !Array.isArray(selectors)) {
        return selectors;
    }

    return selectors.map(item => ({
        ...item,
        selector: item.selector.startsWith('await ') ? item.selector : 'await ' + item.selector
    }));
}

//c# and .net changes start from here

/**
 * Convert Playwright selector from JavaScript to C# format
 * @param {string} selector - Playwright selector string in JavaScript format
 * @returns {string} Selector in C# format
 */
function convertToCSharpPlaywright(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }

    // Extract method and arguments (handle both page. and Page. prefixes)
    const methodMatch = selector.match(/[Pp]age\.(\w+)\((.*)\)$/s);
    if (!methodMatch) {
        return selector;
    }

    const method = methodMatch[1];
    let args = methodMatch[2].trim();

    // Convert camelCase method name to PascalCase for C#
    const csharpMethod = method.charAt(0).toUpperCase() + method.slice(1);

    // Special handling for locator, xpath, css, frameLocator - they use raw selectors
    if (method === 'locator' || method === 'xpath' || method === 'css' || method === 'frameLocator') {
        const singleQuoteMatch = args.match(/^'(.*)'$/s);
        if (singleQuoteMatch) {
            const content = singleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `Page.${csharpMethod}("${convertedContent}")`;
        }

        const doubleQuoteMatch = args.match(/^"(.*)"$/s);
        if (doubleQuoteMatch) {
            const content = doubleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `Page.${csharpMethod}("${convertedContent}")`;
        }

        return `Page.${csharpMethod}(${args})`;
    }

    // Check if there are options
    const hasOptions = /\{[^}]+\}/.test(args);

    if (!hasOptions) {
        // Simple case: just convert quotes and method name to PascalCase
        return `Page.${csharpMethod}(${args.replace(/'/g, '"')})`;
    }

    // Complex case: parse arguments and options
    const complexMatch = args.match(/^(['"])([^'"]+)\1\s*,\s*\{([^}]+)\}/);

    if (!complexMatch) {
        return `page.${csharpMethod}(${args.replace(/'/g, '"')})`;
    }

    const mainArg = complexMatch[2];
    const optionsStr = complexMatch[3];

    // Parse options
    const optionPairs = [];
    let current = '';
    let inQuote = false;
    let quoteChar = '';

    for (let i = 0; i < optionsStr.length; i++) {
        const char = optionsStr[i];
        const prevChar = i > 0 ? optionsStr[i - 1] : '';

        if ((char === '"' || char === "'") && prevChar !== '\\') {
            if (!inQuote) {
                inQuote = true;
                quoteChar = char;
            } else if (char === quoteChar) {
                inQuote = false;
            }
        }

        if (char === ',' && !inQuote) {
            optionPairs.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }

    if (current.trim()) {
        optionPairs.push(current.trim());
    }

    // Convert options to C# property initializer syntax
    const csharpOptions = optionPairs.map(pair => {
        // Match string values: key: 'value'
        const stringMatch = pair.match(/(\w+):\s*(['"])([^'"]*)\2/);
        if (stringMatch) {
            const [, key, , value] = stringMatch;
            const propName = key.charAt(0).toUpperCase() + key.slice(1);
            return `${propName} = "${value}"`;
        }

        // Match boolean values: key: true/false
        const boolMatch = pair.match(/(\w+):\s*(true|false)/i);
        if (boolMatch) {
            const [, key, value] = boolMatch;
            const propName = key.charAt(0).toUpperCase() + key.slice(1);
            const csharpValue = value.toLowerCase() === 'true' ? 'true' : 'false';
            return `${propName} = ${csharpValue}`;
        }

        // Match numeric values: key: 123
        const numMatch = pair.match(/(\w+):\s*(\d+)/);
        if (numMatch) {
            const [, key, value] = numMatch;
            const propName = key.charAt(0).toUpperCase() + key.slice(1);
            return `${propName} = ${value}`;
        }

        return '';
    }).filter(Boolean).join(', ');

    // Build final C# selector based on method type
    let result;

    switch (method) {
        case 'getByRole':
            const roleEnum = mainArg
                .replace(/([a-z])([A-Z])/g, '$1_$2')
                .toUpperCase();
            if (csharpOptions) {
                result = `Page.GetByRole(AriaRole.${roleEnum}, new Page.GetByRoleOptions { ${csharpOptions} })`;
            } else {
                result = `Page.GetByRole(AriaRole.${roleEnum})`;
            }
            break;

        case 'getByLabel':
        case 'getByPlaceholder':
        case 'getByText':
        case 'getByTitle':
        case 'getByAltText':
            const optionsClass = getCSharpOptionsClass(method);
            if (csharpOptions) {
                result = `Page.${csharpMethod}("${mainArg}", new ${optionsClass} { ${csharpOptions} })`;
            } else {
                result = `Page.${csharpMethod}("${mainArg}")`;
            }
            break;

        case 'getByTestId':
            result = `Page.GetByTestId("${mainArg}")`;
            break;

        default:
            if (csharpOptions) {
                result = `Page.${csharpMethod}("${mainArg}", new Page.GetByTextOptions { ${csharpOptions} })`;
            } else {
                result = `Page.${csharpMethod}("${mainArg}")`;
            }
    }

    return result;
}

/**
 * Get the C# options class name for a method
 * @param {string} method - Method name
 * @returns {string} C# options class name
 */
function getCSharpOptionsClass(method) {
    const classMap = {
        'getByText': 'Page.GetByTextOptions',
        'getByLabel': 'Page.GetByLabelOptions',
        'getByPlaceholder': 'Page.GetByPlaceholderOptions',
        'getByTitle': 'Page.GetByTitleOptions',
        'getByAltText': 'Page.GetByAltTextOptions'
    };
    return classMap[method] || 'Page.GetByTextOptions';
}

/**
 * Convert chained Playwright selector from JavaScript to C# format
 * @param {string} selector - Playwright selector string with potential chaining
 * @returns {string} C# formatted selector with chaining
 */
function convertToCSharpPlaywrightWithChaining(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }

    let convertedSelector = '';
    let remaining = selector;

    // Process each method in the chain
    while (remaining) {
        // Check if it's the first method (page.method or Page.method)
        const pageMethodMatch = remaining.match(/^[Pp]age\.(\w+)\(([^)]*)\)/);
        if (pageMethodMatch) {
            const [fullMatch, method, args] = pageMethodMatch;
            convertedSelector += convertSingleCSharpMethod('Page.' + method, args.trim());
            remaining = remaining.substring(fullMatch.length);
            continue;
        }

        // Match chained method: .method(args)
        const methodMatch = remaining.match(/^\.(\w+)\(([^)]*)\)/);
        if (methodMatch) {
            const [fullMatch, method, args] = methodMatch;
            convertedSelector += '.' + convertSingleCSharpMethod(method, args.trim());
            remaining = remaining.substring(fullMatch.length);
        } else {
            break;
        }
    }

    return convertedSelector || selector;
}

/**
 * Convert a single method call for C# (helper function)
 * @param {string} method - Method name (with or without 'page.')
 * @param {string} args - Arguments string
 * @returns {string} Converted method call
 */
function convertSingleCSharpMethod(method, args) {
    const isPageMethod = method.startsWith('Page.');
    const actualMethod = isPageMethod ? method.substring(5) : method;
    const csharpMethod = actualMethod.charAt(0).toUpperCase() + actualMethod.slice(1);
    const prefix = isPageMethod ? 'Page.' : '';

    // Special handling for locator, xpath, css, frameLocator
    if (actualMethod === 'locator' || actualMethod === 'xpath' || actualMethod === 'css' || actualMethod === 'frameLocator') {
        const singleQuoteMatch = args.match(/^'(.*)'$/s);
        if (singleQuoteMatch) {
            const content = singleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `${prefix}${csharpMethod}("${convertedContent}")`;
        }

        const doubleQuoteMatch = args.match(/^"(.*)"$/s);
        if (doubleQuoteMatch) {
            const content = doubleQuoteMatch[1];
            const convertedContent = content.replace(/"/g, "'");
            return `${prefix}${csharpMethod}("${convertedContent}")`;
        }

        return `${prefix}${csharpMethod}(${args})`;
    }

    // Handle filter method with options object
    if (actualMethod === 'filter') {
        return convertCSharpFilterMethod(args);
    }

    // Handle first, last, nth methods
    if (actualMethod === 'first' || actualMethod === 'last') {
        return `${csharpMethod}()`;
    }

    if (actualMethod === 'nth') {
        return `Nth(${args})`;
    }

    // Check if there are options
    const hasOptions = /\{[^}]+\}/.test(args);

    if (!hasOptions) {
        // Simple case: convert quotes and method name to PascalCase
        return `${prefix}${csharpMethod}(${args.replace(/'/g, '"')})`;
    }

    // Complex case: parse arguments and options
    const complexMatch = args.match(/^(['"])([^'"]+)\1\s*,\s*\{([^}]+)\}$/);

    if (!complexMatch) {
        return `${prefix}${csharpMethod}(${args.replace(/'/g, '"')})`;
    }

    const mainArg = complexMatch[2];
    const optionsStr = complexMatch[3].trim();

    // Parse options more carefully
    const csharpKwargs = [];
    let currentOption = '';
    let depth = 0;
    let inString = false;
    let stringChar = '';

    for (let i = 0; i < optionsStr.length; i++) {
        const char = optionsStr[i];
        const prevChar = i > 0 ? optionsStr[i - 1] : '';

        // Track string boundaries
        if ((char === '"' || char === "'") && prevChar !== '\\') {
            if (!inString) {
                inString = true;
                stringChar = char;
            } else if (char === stringChar) {
                inString = false;
            }
        }

        // Track depth for nested objects
        if (!inString) {
            if (char === '{' || char === '[') depth++;
            if (char === '}' || char === ']') depth--;
        }

        // Split on comma only at depth 0 and outside strings
        if (char === ',' && depth === 0 && !inString) {
            if (currentOption.trim()) {
                csharpKwargs.push(convertCSharpOption(currentOption.trim()));
            }
            currentOption = '';
        } else {
            currentOption += char;
        }
    }

    if (currentOption.trim()) {
        csharpKwargs.push(convertCSharpOption(currentOption.trim()));
    }

    // Filter out empty strings
    const validKwargs = csharpKwargs.filter(kwarg => kwarg && kwarg.length > 0);

    // Build C# method call
    const optionsClass = getCSharpOptionsClass(actualMethod);
    if (validKwargs.length > 0) {
        return `${prefix}${csharpMethod}("${mainArg}", new ${optionsClass} { ${validKwargs.join(', ')} })`;
    } else {
        return `${prefix}${csharpMethod}("${mainArg}")`;
    }
}

/**
 * Convert a single C# option (key: value pair)
 * @param {string} option - Option string like "exact: true"
 * @returns {string} C# property initializer like "Exact = true"
 */
function convertCSharpOption(option) {
    // Try to match string values: key: 'value' or key: "value"
    const stringMatch = option.match(/^(\w+)\s*:\s*(['"])([^'"]*)\2$/);
    if (stringMatch) {
        const [, key, , value] = stringMatch;
        const propName = key.charAt(0).toUpperCase() + key.slice(1);
        return `${propName} = "${value}"`;
    }

    // Try to match boolean values: key: true or key: false
    const boolMatch = option.match(/^(\w+)\s*:\s*(true|false)$/i);
    if (boolMatch) {
        const [, key, value] = boolMatch;
        const propName = key.charAt(0).toUpperCase() + key.slice(1);
        // C# uses lowercase true/false
        const csharpValue = value.toLowerCase() === 'true' ? 'true' : 'false';
        return `${propName} = ${csharpValue}`;
    }

    // Try to match numeric values: key: 123
    const numMatch = option.match(/^(\w+)\s*:\s*(\d+)$/);
    if (numMatch) {
        const [, key, value] = numMatch;
        const propName = key.charAt(0).toUpperCase() + key.slice(1);
        return `${propName} = ${value}`;
    }

    // Try to match regex patterns: key: /pattern/flags
    const regexMatch = option.match(/^(\w+)\s*:\s*\/(.+?)\/([gimsuy]*)$/);
    if (regexMatch) {
        const [, key, pattern, flags] = regexMatch;
        const propName = key.charAt(0).toUpperCase() + key.slice(1);
        // C# uses Regex class
        return `${propName} = new Regex(@"${pattern}"${flags ? ', RegexOptions.' + convertCSharpRegexFlags(flags) : ''})`;
    }

    // If nothing matches, return empty string
    return '';
}

/**
 * Convert regex flags from JavaScript to C#
 * @param {string} flags - JavaScript regex flags
 * @returns {string} C# regex flags
 */
function convertCSharpRegexFlags(flags) {
    const flagMap = {
        'i': 'IgnoreCase',
        'm': 'Multiline',
        's': 'Singleline',
        'g': '' // C# Regex.Matches for global equivalent
    };

    return flags.split('')
        .map(f => flagMap[f] || '')
        .filter(Boolean)
        .join(' | RegexOptions.');
}

/**
 * Convert filter method with options for C#
 * @param {string} args - Arguments for filter method
 * @returns {string} C# formatted filter method
 */
function convertCSharpFilterMethod(args) {
    // Match object pattern: { hasText: 'value' } or { has: page.locator('...') }
    const objectMatch = args.match(/^\{([^}]+)\}$/);

    if (!objectMatch) {
        return `Filter(${args.replace(/'/g, '"')})`;
    }

    const content = objectMatch[1].trim();

    // Check for hasText (C# uses HasText)
    const hasTextMatch = content.match(/hasText:\s*(['"])([^'"]+)\1/);
    if (hasTextMatch) {
        const text = hasTextMatch[2];
        return `Filter(new Locator.FilterOptions { HasText = "${text}" })`;
    }

    // Check for has with locator
    const hasLocatorMatch = content.match(/has:\s*(page\.locator\([^)]+\))/);
    if (hasLocatorMatch) {
        const locator = hasLocatorMatch[1];
        const convertedLocator = convertToCSharpPlaywrightWithChaining(locator);
        return `Filter(new Locator.FilterOptions { Has = ${convertedLocator} })`;
    }

    // Check for hasNot
    const hasNotMatch = content.match(/hasNot:\s*(page\.locator\([^)]+\))/);
    if (hasNotMatch) {
        const locator = hasNotMatch[1];
        const convertedLocator = convertToCSharpPlaywrightWithChaining(locator);
        return `Filter(new Locator.FilterOptions { HasNot = ${convertedLocator} })`;
    }

    return `Filter(${args.replace(/'/g, '"')})`;
}

/**
 * Advanced C# conversion with chaining support
 * @param {string} selector - Playwright selector string
 * @returns {string} C# formatted selector
 */
function convertToCSharpPlaywrightAdvanced(selector) {
    if (!selector || typeof selector !== 'string') {
        return selector;
    }

    // Check if selector has chaining (contains multiple method calls)
    const hasChaining = (selector.match(/\)\./g) || []).length > 0;

    if (hasChaining) {
        return convertToCSharpPlaywrightWithChaining(selector);
    }

    // Original logic for non-chained selectors
    const methodMatch = selector.match(/[Pp]age\.(\w+)\((.*)\)$/s);
    if (!methodMatch) {
        return selector;
    }

    const method = methodMatch[1];
    let args = methodMatch[2].trim();

    return convertSingleCSharpMethod('Page.' + method, args);
}

/**
 * Convert all selectors in array to C# Playwright format
 * @param {Array} selectors - Array of selector objects with {selector, count}
 * @returns {Array} Array with C# formatted selectors
 */
function convertSelectorsToCSharpPlaywright(selectors) {
    if (!selectors || !Array.isArray(selectors)) {
        return selectors;
    }

    return selectors.map(item => ({
        ...item,
        selector: convertToCSharpPlaywrightAdvanced(item.selector)
    }));
}

